﻿namespace projet_stage
{
    partial class gerez
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(gerez));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tb_email = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tb_matricule = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tb_mdp = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tb_adresse = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.retourToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deconnexionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox4);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Location = new System.Drawing.Point(12, 170);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(500, 164);
            this.groupBox8.TabIndex = 15;
            this.groupBox8.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tb_email);
            this.groupBox4.Location = new System.Drawing.Point(12, 11);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 56);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            // 
            // tb_email
            // 
            this.tb_email.AcceptsReturn = false;
            this.tb_email.AcceptsTab = false;
            this.tb_email.AnimationSpeed = 200;
            this.tb_email.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_email.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_email.BackColor = System.Drawing.Color.Transparent;
            this.tb_email.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_email.BackgroundImage")));
            this.tb_email.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_email.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_email.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_email.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_email.BorderRadius = 1;
            this.tb_email.BorderThickness = 1;
            this.tb_email.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_email.DefaultText = "";
            this.tb_email.FillColor = System.Drawing.Color.White;
            this.tb_email.HideSelection = true;
            this.tb_email.IconLeft = null;
            this.tb_email.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.IconPadding = 10;
            this.tb_email.IconRight = null;
            this.tb_email.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.Lines = new string[0];
            this.tb_email.Location = new System.Drawing.Point(0, 6);
            this.tb_email.MaxLength = 32767;
            this.tb_email.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_email.Modified = false;
            this.tb_email.Multiline = false;
            this.tb_email.Name = "tb_email";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_email.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnIdleState = stateProperties4;
            this.tb_email.PasswordChar = '\0';
            this.tb_email.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_email.PlaceholderText = "Enter votre e-mail";
            this.tb_email.ReadOnly = false;
            this.tb_email.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_email.SelectedText = "";
            this.tb_email.SelectionLength = 0;
            this.tb_email.SelectionStart = 0;
            this.tb_email.ShortcutsEnabled = true;
            this.tb_email.Size = new System.Drawing.Size(200, 35);
            this.tb_email.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_email.TabIndex = 4;
            this.tb_email.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_email.TextMarginBottom = 0;
            this.tb_email.TextMarginLeft = 5;
            this.tb_email.TextMarginTop = 0;
            this.tb_email.TextPlaceholder = "Enter votre e-mail";
            this.tb_email.UseSystemPasswordChar = false;
            this.tb_email.WordWrap = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tb_matricule);
            this.groupBox9.Location = new System.Drawing.Point(12, 90);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(200, 56);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            // 
            // tb_matricule
            // 
            this.tb_matricule.AcceptsReturn = false;
            this.tb_matricule.AcceptsTab = false;
            this.tb_matricule.AnimationSpeed = 200;
            this.tb_matricule.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_matricule.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_matricule.BackColor = System.Drawing.Color.Transparent;
            this.tb_matricule.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_matricule.BackgroundImage")));
            this.tb_matricule.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_matricule.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_matricule.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_matricule.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_matricule.BorderRadius = 1;
            this.tb_matricule.BorderThickness = 1;
            this.tb_matricule.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tb_matricule.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_matricule.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_matricule.DefaultText = "";
            this.tb_matricule.FillColor = System.Drawing.Color.White;
            this.tb_matricule.HideSelection = true;
            this.tb_matricule.IconLeft = null;
            this.tb_matricule.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_matricule.IconPadding = 10;
            this.tb_matricule.IconRight = null;
            this.tb_matricule.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_matricule.Lines = new string[0];
            this.tb_matricule.Location = new System.Drawing.Point(0, 8);
            this.tb_matricule.MaxLength = 32767;
            this.tb_matricule.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_matricule.Modified = false;
            this.tb_matricule.Multiline = false;
            this.tb_matricule.Name = "tb_matricule";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_matricule.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_matricule.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_matricule.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_matricule.OnIdleState = stateProperties8;
            this.tb_matricule.PasswordChar = '\0';
            this.tb_matricule.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_matricule.PlaceholderText = "ENTER VOTRE MATRICULE";
            this.tb_matricule.ReadOnly = false;
            this.tb_matricule.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_matricule.SelectedText = "";
            this.tb_matricule.SelectionLength = 0;
            this.tb_matricule.SelectionStart = 0;
            this.tb_matricule.ShortcutsEnabled = true;
            this.tb_matricule.Size = new System.Drawing.Size(200, 35);
            this.tb_matricule.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_matricule.TabIndex = 4;
            this.tb_matricule.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_matricule.TextMarginBottom = 0;
            this.tb_matricule.TextMarginLeft = 5;
            this.tb_matricule.TextMarginTop = 0;
            this.tb_matricule.TextPlaceholder = "ENTER VOTRE MATRICULE";
            this.tb_matricule.UseSystemPasswordChar = false;
            this.tb_matricule.WordWrap = true;
            // 
            // tb_mdp
            // 
            this.tb_mdp.AcceptsReturn = false;
            this.tb_mdp.AcceptsTab = false;
            this.tb_mdp.AnimationSpeed = 200;
            this.tb_mdp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_mdp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_mdp.BackColor = System.Drawing.Color.Transparent;
            this.tb_mdp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_mdp.BackgroundImage")));
            this.tb_mdp.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_mdp.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_mdp.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_mdp.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_mdp.BorderRadius = 1;
            this.tb_mdp.BorderThickness = 1;
            this.tb_mdp.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_mdp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mdp.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_mdp.DefaultText = "";
            this.tb_mdp.FillColor = System.Drawing.Color.White;
            this.tb_mdp.HideSelection = true;
            this.tb_mdp.IconLeft = null;
            this.tb_mdp.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mdp.IconPadding = 10;
            this.tb_mdp.IconRight = null;
            this.tb_mdp.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mdp.Lines = new string[0];
            this.tb_mdp.Location = new System.Drawing.Point(179, 11);
            this.tb_mdp.MaxLength = 32767;
            this.tb_mdp.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_mdp.Modified = false;
            this.tb_mdp.Multiline = false;
            this.tb_mdp.Name = "tb_mdp";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_mdp.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_mdp.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_mdp.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_mdp.OnIdleState = stateProperties12;
            this.tb_mdp.PasswordChar = '\0';
            this.tb_mdp.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_mdp.PlaceholderText = "Enter votre mot de passe";
            this.tb_mdp.ReadOnly = false;
            this.tb_mdp.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_mdp.SelectedText = "";
            this.tb_mdp.SelectionLength = 0;
            this.tb_mdp.SelectionStart = 0;
            this.tb_mdp.ShortcutsEnabled = true;
            this.tb_mdp.Size = new System.Drawing.Size(188, 35);
            this.tb_mdp.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_mdp.TabIndex = 4;
            this.tb_mdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_mdp.TextMarginBottom = 0;
            this.tb_mdp.TextMarginLeft = 5;
            this.tb_mdp.TextMarginTop = 0;
            this.tb_mdp.TextPlaceholder = "Enter votre mot de passe";
            this.tb_mdp.UseSystemPasswordChar = false;
            this.tb_mdp.WordWrap = true;
            // 
            // tb_adresse
            // 
            this.tb_adresse.AcceptsReturn = false;
            this.tb_adresse.AcceptsTab = false;
            this.tb_adresse.AnimationSpeed = 200;
            this.tb_adresse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_adresse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_adresse.BackColor = System.Drawing.Color.Transparent;
            this.tb_adresse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_adresse.BackgroundImage")));
            this.tb_adresse.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_adresse.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_adresse.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_adresse.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_adresse.BorderRadius = 1;
            this.tb_adresse.BorderThickness = 1;
            this.tb_adresse.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_adresse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_adresse.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_adresse.DefaultText = "";
            this.tb_adresse.FillColor = System.Drawing.Color.White;
            this.tb_adresse.HideSelection = true;
            this.tb_adresse.IconLeft = null;
            this.tb_adresse.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_adresse.IconPadding = 10;
            this.tb_adresse.IconRight = null;
            this.tb_adresse.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_adresse.Lines = new string[0];
            this.tb_adresse.Location = new System.Drawing.Point(6, 11);
            this.tb_adresse.MaxLength = 32767;
            this.tb_adresse.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_adresse.Modified = false;
            this.tb_adresse.Multiline = false;
            this.tb_adresse.Name = "tb_adresse";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_adresse.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_adresse.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_adresse.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_adresse.OnIdleState = stateProperties16;
            this.tb_adresse.PasswordChar = '\0';
            this.tb_adresse.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_adresse.PlaceholderText = "Enter votre Adresse";
            this.tb_adresse.ReadOnly = false;
            this.tb_adresse.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_adresse.SelectedText = "";
            this.tb_adresse.SelectionLength = 0;
            this.tb_adresse.SelectionStart = 0;
            this.tb_adresse.ShortcutsEnabled = true;
            this.tb_adresse.Size = new System.Drawing.Size(167, 35);
            this.tb_adresse.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_adresse.TabIndex = 4;
            this.tb_adresse.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_adresse.TextMarginBottom = 0;
            this.tb_adresse.TextMarginLeft = 5;
            this.tb_adresse.TextMarginTop = 0;
            this.tb_adresse.TextPlaceholder = "Enter votre Adresse";
            this.tb_adresse.UseSystemPasswordChar = false;
            this.tb_adresse.WordWrap = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tb_mdp);
            this.groupBox1.Controls.Add(this.tb_adresse);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(12, 108);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(500, 56);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(373, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 35);
            this.button1.TabIndex = 5;
            this.button1.Text = "Rechercher";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuMaterialTextbox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuMaterialTextbox1.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Enabled = false;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Century Gothic", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox1.HintText = "";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.Black;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineThickness = 5;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(102, 25);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.MaxLength = 32767;
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(311, 65);
            this.bunifuMaterialTextbox1.TabIndex = 16;
            this.bunifuMaterialTextbox1.Text = "Gérez votre compte .";
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifuButton1);
            this.groupBox2.Location = new System.Drawing.Point(276, 179);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(183, 67);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = false;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "Modifier";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges1;
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.IdleBorderRadius = 3;
            this.bunifuButton1.IdleBorderThickness = 1;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.IdleIconLeftImage = null;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(6, 11);
            this.bunifuButton1.Name = "bunifuButton1";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties17.BorderRadius = 3;
            stateProperties17.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties17.BorderThickness = 1;
            stateProperties17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties17.ForeColor = System.Drawing.Color.White;
            stateProperties17.IconLeftImage = null;
            stateProperties17.IconRightImage = null;
            this.bunifuButton1.onHoverState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties18.BorderRadius = 3;
            stateProperties18.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties18.BorderThickness = 1;
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties18.ForeColor = System.Drawing.Color.White;
            stateProperties18.IconLeftImage = null;
            stateProperties18.IconRightImage = null;
            this.bunifuButton1.OnPressedState = stateProperties18;
            this.bunifuButton1.Size = new System.Drawing.Size(171, 41);
            this.bunifuButton1.TabIndex = 17;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuButton1.UseDefaultRadiusAndThickness = true;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.bunifuButton2);
            this.groupBox3.Location = new System.Drawing.Point(276, 258);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(183, 67);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "Supprimer";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges2;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton2.IdleBorderRadius = 3;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton2.IdleIconLeftImage = null;
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(6, 13);
            this.bunifuButton2.Name = "bunifuButton2";
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.BorderRadius = 3;
            stateProperties19.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties19.BorderThickness = 1;
            stateProperties19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.ForeColor = System.Drawing.Color.White;
            stateProperties19.IconLeftImage = null;
            stateProperties19.IconRightImage = null;
            this.bunifuButton2.onHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties20.BorderRadius = 3;
            stateProperties20.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties20.BorderThickness = 1;
            stateProperties20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties20.ForeColor = System.Drawing.Color.White;
            stateProperties20.IconLeftImage = null;
            stateProperties20.IconRightImage = null;
            this.bunifuButton2.OnPressedState = stateProperties20;
            this.bunifuButton2.Size = new System.Drawing.Size(177, 41);
            this.bunifuButton2.TabIndex = 17;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.retourToolStripMenuItem,
            this.deconnexionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(520, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // retourToolStripMenuItem
            // 
            this.retourToolStripMenuItem.Name = "retourToolStripMenuItem";
            this.retourToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.retourToolStripMenuItem.Text = "Retour";
            this.retourToolStripMenuItem.Click += new System.EventHandler(this.retourToolStripMenuItem_Click);
            // 
            // deconnexionToolStripMenuItem
            // 
            this.deconnexionToolStripMenuItem.Name = "deconnexionToolStripMenuItem";
            this.deconnexionToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.deconnexionToolStripMenuItem.Text = "Deconnexion";
            this.deconnexionToolStripMenuItem.Click += new System.EventHandler(this.deconnexionToolStripMenuItem_Click);
            // 
            // gerez
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 340);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bunifuMaterialTextbox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox8);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "gerez";
            this.Text = "gerez les comptes";
            this.Load += new System.EventHandler(this.gerez_Load);
            this.groupBox8.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_matricule;
        private System.Windows.Forms.GroupBox groupBox4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_email;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_adresse;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox9;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_mdp;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem retourToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deconnexionToolStripMenuItem;
    }
}