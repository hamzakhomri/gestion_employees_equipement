﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class valid_conge : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mn;
        SqlDataAdapter dat;
        SqlDataAdapter dat1;
        SqlCommandBuilder builder;
      
        DataSet data_set = new DataSet();
        DataTable data_table;
        DataTable dt1 = new DataTable("upper");
        SqlDataAdapter data_adapter;
        int pos = 0;

        public void vider()
        {
            tb_categorie.Clear();
            tb_date_debut.Text = DateTime.Now.ToString();
            tb_date_demande.Text = DateTime.Now.ToString();
            tb_date_fin.Text = DateTime.Now.ToString();
            tb_matricule.Clear();
            tb_nature.Clear();
            tb_nm_jour.Clear();
            tb_nom.Clear();
            tb_n_dmande.Clear();
            tb_prenom.Clear();
            tb_search.Clear();
            tb_service.Clear();
        }

        void sum()
        {
            string req = " select sum(nmb_jour) from congé where matricule = @matr ";
            con.Open();
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_matricule.Text);
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();
                textBox1.Text = lec.GetValue(0).ToString();
            }
            if (mn == null)
            {

            }
            con.Close();
        }
        public void navig()
        {
            DataRow dt = data_set.Tables["upper"].Rows[pos];

            tb_n_dmande.Text = dt[0].ToString();
            tb_matricule.Text = dt[1].ToString();
            tb_nom.Text = dt[2].ToString();
            tb_prenom.Text = dt[3].ToString();
            tb_categorie.Text = dt[4].ToString();
            tb_nature.Text = dt[5].ToString();
            tb_service.Text = dt[6].ToString();
            tb_date_demande.Value = DateTime.Parse(dt[7].ToString());
            tb_date_debut.Value = DateTime.Parse(dt[8].ToString());
            tb_date_fin.Value = DateTime.Parse(dt[9].ToString());
            tb_nm_jour.Text = dt[10].ToString();

            label1.Text = pos + 1 + "/" + data_set.Tables["upper"].Rows.Count;
        }

        public void matricule_tb()
        {
            string req = "select  c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour from congé c inner join employe e on c.matricule=e.matricule where c.num_demande =@matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", int.Parse(tb_search.Text));
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
            mn= lec.GetValue(0).ToString();
            tb_n_dmande.Text = lec.GetValue(0).ToString();
            tb_matricule.Text = lec.GetValue(1).ToString();
            tb_nom.Text = lec.GetValue(2).ToString();
            tb_prenom.Text = lec.GetValue(3).ToString();
            tb_categorie.Text = lec.GetValue(4).ToString();
            tb_nature.Text = lec.GetValue(5).ToString();
            tb_service.Text = lec.GetValue(6).ToString();
            tb_date_demande.Text = lec.GetValue(7).ToString();
            tb_date_debut.Text = lec.GetValue(8).ToString();
            tb_date_fin.Text = lec.GetValue(9).ToString();
            tb_nm_jour.Text = lec.GetValue(10).ToString();
            }
            if (mn == null)
            {
                MessageBox.Show("Se Demande N'existe Pas", "Vérifier", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            lec.Close();
            con.Close();
        }
        public void matr_dgv ()
        {
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,e.entite,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour from congé c inner join employe e on c.matricule=e.matricule where c.num_demande =@matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_search.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
              lec.Close();
              con.Close();         
         }
        public void valid()
        {
            string vd = "valider";
            string req = "update congé set validaton = @valid where num_demande=@matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@valid",vd);
            cmd.Parameters.AddWithValue("@matr", int.Parse(tb_n_dmande.Text));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            tb_search.Clear();
            rb_valider.Checked = false;
            MessageBox.Show("Ce congé a été Valider", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void non_valid()
        {
            string  nvd = "NonValider";
            string req = "update congé set validaton = @valid where num_demande=@matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@valid", nvd);
            cmd.Parameters.AddWithValue("@matr",tb_n_dmande.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            tb_search.Clear();
            rb_non_valider.Checked = false;
            MessageBox.Show("Ce congé a été non Valider","",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        public valid_conge()
        {
            InitializeComponent();
        }
        void dgv()
        {
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,e.entite,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour from congé c inner join employe e on c.matricule=e.matricule order by c.num_demande asc";
            dat = new SqlDataAdapter(req, con);
            builder = new SqlCommandBuilder(dat);
            data_table = new DataTable("congé");
            dat.Fill(data_table);
            dataGridView1.DataSource = dat;
        }
        
        private void afficher_dgv()
        {
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour from congé c inner join employe e on c.matricule=e.matricule order by c.num_demande asc";
            data_adapter = new SqlDataAdapter(req, con);
            data_table = new DataTable();
            data_adapter.Fill(data_table);
            dataGridView1.DataSource = data_table;
        }

        private void valid_conge_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour from congé c inner join employe e on c.matricule=e.matricule order by c.num_demande asc";
            dat1 = new SqlDataAdapter(req, con);
            data_set.Tables.Add(dt1);
            dat1.Fill(data_set,"upper");
            dataGridView1.DataSource = data_set.Tables["upper"];
            afficher_dgv();

        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            label1.Visible = true;
            if (pos < data_set.Tables["upper"].Rows.Count-1)
            {
                pos++;
                navig();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            label1.Visible = true;

            pos = 0;
            navig();
            //20h=> 450 DH
        }

        private void button4_Click_1(object sender, EventArgs e)
        {

            label1.Visible = true;
            pos = data_table.Rows.Count - 1;
            navig();
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            label1.Visible = true;
            if ( pos>0)
            {
                pos--;
                navig();
            }
        }
   

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
           
            if (tb_search.Text == "")
            {
                MessageBox.Show("La rechercher n'est pas complet");
            }
            else
            {
              matricule_tb();
              sum();
            }
           
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Il faut rechercher D'abord", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            if (rb_non_valider.Checked == true)
            {
                non_valid();  

            }
            else if (rb_valider.Checked == true)
            {

              
                if (int.Parse(textBox1.Text)<=30)
                {
                    valid();
                }
                else
                {
                    MessageBox.Show("Vou avez Dépassez les nombres des jours autorisé , votre Demande est invalide", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    non_valid();
                    vider();
                }
            }
            vider();
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
           
            vider();
            afficher_dgv();
            label1.Visible = false;
        }
    }
}
