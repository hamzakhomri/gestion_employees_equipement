﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class page1 : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mn;

        public page1()
        {
            InitializeComponent();
        }

        void clear()
        {
            tb_cat.Clear(); tb_email.Clear(); tb_matricule.Clear(); tb_nom.Clear(); tb_prenom.Clear();
            tb_service.Clear(); tb_tel.Clear();
            label4.Text = "";
            label3.Text = "";
            tb_matricule.Focus();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            mn = null;

            if (tb_matricule.Text == "" && tb_email.Text == "" && tb_nom.Text == "" && tb_nom.Text == "" && tb_prenom.Text == "" && tb_service.Text == "" && tb_tel.Text == "")
            {
                MessageBox.Show("La recuperation n'été pas complet", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
                if (tb_tel.Text.Length == 13 || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 9) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 8) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 7) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 6) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 5) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 4) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 3) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 2) || char.IsNumber(tb_tel.Text, tb_tel.Text.Length - 1))
                {
                    string req = "select  c.Matricule , e.nom , e.prenom , c.email , e.tel , e.serviice , e.categorie , c.logiin , c.mdp from compte c inner join employe e on c.Matricule=e.matricule where c.Matricule=@matr and e.nom=@nom and e.prenom=@prenom and c.email=@email and e.serviice = @service and e.tel=@tel and e.categorie=@categ";
                    SqlCommand cmd = new SqlCommand(req, con);
                    cmd.Parameters.AddWithValue("@matr", tb_matricule.Text);
                    cmd.Parameters.AddWithValue("@email", tb_email.Text);
                    cmd.Parameters.AddWithValue("@nom", tb_nom.Text);
                    cmd.Parameters.AddWithValue("@prenom", tb_prenom.Text);
                    cmd.Parameters.AddWithValue("@categ", tb_cat.Text);
                    cmd.Parameters.AddWithValue("@service", tb_service.Text);
                    cmd.Parameters.AddWithValue("@tel", double.Parse(tb_tel.Text));
                    con.Open();
                    SqlDataReader lec = cmd.ExecuteReader();
                    while (lec.Read())
                    {
                        mn = lec.GetValue(0).ToString(); mn = lec.GetValue(1).ToString(); mn = lec.GetValue(2).ToString(); mn = lec.GetValue(3).ToString(); mn = lec.GetValue(4).ToString(); mn = lec.GetValue(5).ToString(); mn = lec.GetValue(6).ToString();
                    label3.Text = lec.GetValue(7).ToString();
                     label4.Text = lec.GetValue(8).ToString();
                    }
                    lec.Close();
                    con.Close();

                         tb_cat.Clear(); tb_email.Clear(); tb_matricule.Clear(); tb_nom.Clear(); tb_prenom.Clear();
                         tb_service.Clear(); tb_tel.Clear();


            }
                else
                {
                    MessageBox.Show("Le numero de telephone est incorrect.                                                 le numero doit étre en début 212.........");
                    return;
                }

                if (mn == null)
            {
                MessageBox.Show("Desole Les données est incorrect ou votre compte est introuvable.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void page1_Load(object sender, EventArgs e)
        {
            
        }
    } 
}
