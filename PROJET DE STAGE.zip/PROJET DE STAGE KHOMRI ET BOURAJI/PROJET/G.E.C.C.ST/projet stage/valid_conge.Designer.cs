﻿namespace projet_stage
{
    partial class valid_conge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(valid_conge));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.tb_date_debut = new System.Windows.Forms.DateTimePicker();
            this.tb_date_demande = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_service = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tb_nm_jour = new System.Windows.Forms.TextBox();
            this.tb_matricule = new System.Windows.Forms.TextBox();
            this.tb_date_fin = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_nature = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tb_n_dmande = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_categorie = new System.Windows.Forms.TextBox();
            this.tb_nom = new System.Windows.Forms.TextBox();
            this.tb_prenom = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rb_non_valider = new System.Windows.Forms.RadioButton();
            this.button6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.rb_valider = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.button3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.button4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.dataGridView1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_date_debut
            // 
            this.tb_date_debut.Enabled = false;
            this.tb_date_debut.Location = new System.Drawing.Point(735, 42);
            this.tb_date_debut.Name = "tb_date_debut";
            this.tb_date_debut.Size = new System.Drawing.Size(179, 20);
            this.tb_date_debut.TabIndex = 6;
            // 
            // tb_date_demande
            // 
            this.tb_date_demande.Enabled = false;
            this.tb_date_demande.Location = new System.Drawing.Point(735, 16);
            this.tb_date_demande.Name = "tb_date_demande";
            this.tb_date_demande.Size = new System.Drawing.Size(179, 20);
            this.tb_date_demande.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(623, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Date Debut :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(623, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Date demande :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(310, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "Service :";
            // 
            // tb_service
            // 
            this.tb_service.Enabled = false;
            this.tb_service.Location = new System.Drawing.Point(422, 97);
            this.tb_service.Name = "tb_service";
            this.tb_service.Size = new System.Drawing.Size(165, 20);
            this.tb_service.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(623, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Nombe des joures :";
            // 
            // tb_nm_jour
            // 
            this.tb_nm_jour.Enabled = false;
            this.tb_nm_jour.Location = new System.Drawing.Point(735, 94);
            this.tb_nm_jour.Name = "tb_nm_jour";
            this.tb_nm_jour.Size = new System.Drawing.Size(179, 20);
            this.tb_nm_jour.TabIndex = 0;
            // 
            // tb_matricule
            // 
            this.tb_matricule.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tb_matricule.Enabled = false;
            this.tb_matricule.Location = new System.Drawing.Point(94, 54);
            this.tb_matricule.Name = "tb_matricule";
            this.tb_matricule.Size = new System.Drawing.Size(163, 20);
            this.tb_matricule.TabIndex = 0;
            // 
            // tb_date_fin
            // 
            this.tb_date_fin.Enabled = false;
            this.tb_date_fin.Location = new System.Drawing.Point(735, 68);
            this.tb_date_fin.Name = "tb_date_fin";
            this.tb_date_fin.Size = new System.Drawing.Size(179, 20);
            this.tb_date_fin.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(310, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Nature de conge :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(623, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Date Fin :";
            // 
            // tb_nature
            // 
            this.tb_nature.Enabled = false;
            this.tb_nature.Location = new System.Drawing.Point(422, 71);
            this.tb_nature.Name = "tb_nature";
            this.tb_nature.Size = new System.Drawing.Size(165, 20);
            this.tb_nature.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.tb_search);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(238, 125);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Rechercher par Num de demande";
            // 
            // button5
            // 
            this.button5.AllowToggling = false;
            this.button5.AnimationSpeed = 200;
            this.button5.AutoGenerateColors = false;
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackColor1 = System.Drawing.Color.Green;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.button5.ButtonText = "OK";
            this.button5.ButtonTextMarginLeft = 0;
            this.button5.ColorContrastOnClick = 45;
            this.button5.ColorContrastOnHover = 45;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.button5.CustomizableEdges = borderEdges1;
            this.button5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button5.DisabledBorderColor = System.Drawing.Color.Empty;
            this.button5.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.button5.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.button5.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.button5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.button5.IconMarginLeft = 11;
            this.button5.IconPadding = 10;
            this.button5.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.button5.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.button5.IdleBorderRadius = 3;
            this.button5.IdleBorderThickness = 1;
            this.button5.IdleFillColor = System.Drawing.Color.Green;
            this.button5.IdleIconLeftImage = null;
            this.button5.IdleIconRightImage = null;
            this.button5.IndicateFocus = false;
            this.button5.Location = new System.Drawing.Point(33, 66);
            this.button5.Name = "button5";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties1.BorderRadius = 3;
            stateProperties1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties1.ForeColor = System.Drawing.Color.White;
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.button5.onHoverState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.BorderRadius = 3;
            stateProperties2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties2.BorderThickness = 1;
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.ForeColor = System.Drawing.Color.White;
            stateProperties2.IconLeftImage = null;
            stateProperties2.IconRightImage = null;
            this.button5.OnPressedState = stateProperties2;
            this.button5.Size = new System.Drawing.Size(149, 50);
            this.button5.TabIndex = 27;
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button5.TextMarginLeft = 0;
            this.button5.UseDefaultRadiusAndThickness = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // tb_search
            // 
            this.tb_search.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tb_search.Location = new System.Drawing.Point(33, 28);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(149, 22);
            this.tb_search.TabIndex = 25;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "N° demande :";
            // 
            // tb_n_dmande
            // 
            this.tb_n_dmande.Enabled = false;
            this.tb_n_dmande.Location = new System.Drawing.Point(94, 19);
            this.tb_n_dmande.Name = "tb_n_dmande";
            this.tb_n_dmande.Size = new System.Drawing.Size(163, 20);
            this.tb_n_dmande.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Matricule :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.tb_nm_jour);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.tb_n_dmande);
            this.groupBox2.Controls.Add(this.tb_date_debut);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.tb_categorie);
            this.groupBox2.Controls.Add(this.tb_matricule);
            this.groupBox2.Controls.Add(this.tb_date_demande);
            this.groupBox2.Controls.Add(this.tb_nom);
            this.groupBox2.Controls.Add(this.tb_prenom);
            this.groupBox2.Controls.Add(this.tb_service);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tb_date_fin);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.tb_nature);
            this.groupBox2.Location = new System.Drawing.Point(250, 76);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(924, 125);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(310, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Catégorie :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(310, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Prenom :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Nom :";
            // 
            // tb_categorie
            // 
            this.tb_categorie.Enabled = false;
            this.tb_categorie.Location = new System.Drawing.Point(422, 41);
            this.tb_categorie.Name = "tb_categorie";
            this.tb_categorie.Size = new System.Drawing.Size(165, 20);
            this.tb_categorie.TabIndex = 25;
            // 
            // tb_nom
            // 
            this.tb_nom.Enabled = false;
            this.tb_nom.Location = new System.Drawing.Point(94, 94);
            this.tb_nom.Name = "tb_nom";
            this.tb_nom.Size = new System.Drawing.Size(163, 20);
            this.tb_nom.TabIndex = 26;
            // 
            // tb_prenom
            // 
            this.tb_prenom.Enabled = false;
            this.tb_prenom.Location = new System.Drawing.Point(422, 15);
            this.tb_prenom.Name = "tb_prenom";
            this.tb_prenom.Size = new System.Drawing.Size(165, 20);
            this.tb_prenom.TabIndex = 27;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.rb_non_valider);
            this.groupBox5.Controls.Add(this.rb_valider);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Location = new System.Drawing.Point(843, 210);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(331, 49);
            this.groupBox5.TabIndex = 18;
            this.groupBox5.TabStop = false;
            // 
            // rb_non_valider
            // 
            this.rb_non_valider.AutoSize = true;
            this.rb_non_valider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_non_valider.Location = new System.Drawing.Point(87, 14);
            this.rb_non_valider.Name = "rb_non_valider";
            this.rb_non_valider.Size = new System.Drawing.Size(108, 20);
            this.rb_non_valider.TabIndex = 17;
            this.rb_non_valider.TabStop = true;
            this.rb_non_valider.Text = "Non Valider";
            this.rb_non_valider.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.AllowToggling = false;
            this.button6.AnimationSpeed = 200;
            this.button6.AutoGenerateColors = false;
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackColor1 = System.Drawing.Color.Green;
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.button6.ButtonText = "OK";
            this.button6.ButtonTextMarginLeft = 0;
            this.button6.ColorContrastOnClick = 45;
            this.button6.ColorContrastOnHover = 45;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.button6.CustomizableEdges = borderEdges2;
            this.button6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button6.DisabledBorderColor = System.Drawing.Color.Empty;
            this.button6.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.button6.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.button6.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.button6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.button6.IconMarginLeft = 11;
            this.button6.IconPadding = 10;
            this.button6.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.button6.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.button6.IdleBorderRadius = 3;
            this.button6.IdleBorderThickness = 1;
            this.button6.IdleFillColor = System.Drawing.Color.Green;
            this.button6.IdleIconLeftImage = null;
            this.button6.IdleIconRightImage = null;
            this.button6.IndicateFocus = false;
            this.button6.Location = new System.Drawing.Point(201, 9);
            this.button6.Name = "button6";
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.BorderRadius = 3;
            stateProperties3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties3.BorderThickness = 1;
            stateProperties3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.ForeColor = System.Drawing.Color.White;
            stateProperties3.IconLeftImage = null;
            stateProperties3.IconRightImage = null;
            this.button6.onHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties4.BorderRadius = 3;
            stateProperties4.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties4.BorderThickness = 1;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties4.ForeColor = System.Drawing.Color.White;
            stateProperties4.IconLeftImage = null;
            stateProperties4.IconRightImage = null;
            this.button6.OnPressedState = stateProperties4;
            this.button6.Size = new System.Drawing.Size(126, 30);
            this.button6.TabIndex = 29;
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button6.TextMarginLeft = 0;
            this.button6.UseDefaultRadiusAndThickness = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(279, 9);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 20);
            this.textBox1.TabIndex = 31;
            this.textBox1.Visible = false;
            // 
            // rb_valider
            // 
            this.rb_valider.AutoSize = true;
            this.rb_valider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_valider.Location = new System.Drawing.Point(5, 12);
            this.rb_valider.Name = "rb_valider";
            this.rb_valider.Size = new System.Drawing.Size(76, 20);
            this.rb_valider.TabIndex = 10;
            this.rb_valider.TabStop = true;
            this.rb_valider.Text = "Valider";
            this.rb_valider.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button1);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.button4);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Controls.Add(this.button2);
            this.groupBox6.Location = new System.Drawing.Point(183, 204);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(654, 55);
            this.groupBox6.TabIndex = 23;
            this.groupBox6.TabStop = false;
            // 
            // button1
            // 
            this.button1.AllowToggling = false;
            this.button1.AnimationSpeed = 200;
            this.button1.AutoGenerateColors = false;
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackColor1 = System.Drawing.Color.Green;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.button1.ButtonText = "Premier";
            this.button1.ButtonTextMarginLeft = 0;
            this.button1.ColorContrastOnClick = 45;
            this.button1.ColorContrastOnHover = 45;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.button1.CustomizableEdges = borderEdges3;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button1.DisabledBorderColor = System.Drawing.Color.Empty;
            this.button1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.button1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.button1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.button1.IconMarginLeft = 11;
            this.button1.IconPadding = 10;
            this.button1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.button1.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.button1.IdleBorderRadius = 3;
            this.button1.IdleBorderThickness = 1;
            this.button1.IdleFillColor = System.Drawing.Color.Green;
            this.button1.IdleIconLeftImage = null;
            this.button1.IdleIconRightImage = null;
            this.button1.IndicateFocus = false;
            this.button1.Location = new System.Drawing.Point(6, 13);
            this.button1.Name = "button1";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties5.BorderRadius = 3;
            stateProperties5.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties5.BorderThickness = 1;
            stateProperties5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties5.ForeColor = System.Drawing.Color.White;
            stateProperties5.IconLeftImage = null;
            stateProperties5.IconRightImage = null;
            this.button1.onHoverState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties6.BorderRadius = 3;
            stateProperties6.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties6.BorderThickness = 1;
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties6.ForeColor = System.Drawing.Color.White;
            stateProperties6.IconLeftImage = null;
            stateProperties6.IconRightImage = null;
            this.button1.OnPressedState = stateProperties6;
            this.button1.Size = new System.Drawing.Size(123, 36);
            this.button1.TabIndex = 25;
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button1.TextMarginLeft = 0;
            this.button1.UseDefaultRadiusAndThickness = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button3
            // 
            this.button3.AllowToggling = false;
            this.button3.AnimationSpeed = 200;
            this.button3.AutoGenerateColors = false;
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackColor1 = System.Drawing.Color.Green;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.button3.ButtonText = "Precedent";
            this.button3.ButtonTextMarginLeft = 0;
            this.button3.ColorContrastOnClick = 45;
            this.button3.ColorContrastOnHover = 45;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.button3.CustomizableEdges = borderEdges4;
            this.button3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button3.DisabledBorderColor = System.Drawing.Color.Empty;
            this.button3.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.button3.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.button3.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.button3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.button3.IconMarginLeft = 11;
            this.button3.IconPadding = 10;
            this.button3.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.button3.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.button3.IdleBorderRadius = 3;
            this.button3.IdleBorderThickness = 1;
            this.button3.IdleFillColor = System.Drawing.Color.Green;
            this.button3.IdleIconLeftImage = null;
            this.button3.IdleIconRightImage = null;
            this.button3.IndicateFocus = false;
            this.button3.Location = new System.Drawing.Point(135, 13);
            this.button3.Name = "button3";
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.BorderRadius = 3;
            stateProperties7.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties7.BorderThickness = 1;
            stateProperties7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.ForeColor = System.Drawing.Color.White;
            stateProperties7.IconLeftImage = null;
            stateProperties7.IconRightImage = null;
            this.button3.onHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties8.BorderRadius = 3;
            stateProperties8.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties8.BorderThickness = 1;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties8.ForeColor = System.Drawing.Color.White;
            stateProperties8.IconLeftImage = null;
            stateProperties8.IconRightImage = null;
            this.button3.OnPressedState = stateProperties8;
            this.button3.Size = new System.Drawing.Size(123, 36);
            this.button3.TabIndex = 28;
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button3.TextMarginLeft = 0;
            this.button3.UseDefaultRadiusAndThickness = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.AllowToggling = false;
            this.button4.AnimationSpeed = 200;
            this.button4.AutoGenerateColors = false;
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackColor1 = System.Drawing.Color.Green;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.button4.ButtonText = "Dernier";
            this.button4.ButtonTextMarginLeft = 0;
            this.button4.ColorContrastOnClick = 45;
            this.button4.ColorContrastOnHover = 45;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.button4.CustomizableEdges = borderEdges5;
            this.button4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button4.DisabledBorderColor = System.Drawing.Color.Empty;
            this.button4.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.button4.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.button4.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.button4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.button4.IconMarginLeft = 11;
            this.button4.IconPadding = 10;
            this.button4.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.button4.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.button4.IdleBorderRadius = 3;
            this.button4.IdleBorderThickness = 1;
            this.button4.IdleFillColor = System.Drawing.Color.Green;
            this.button4.IdleIconLeftImage = null;
            this.button4.IdleIconRightImage = null;
            this.button4.IndicateFocus = false;
            this.button4.Location = new System.Drawing.Point(527, 13);
            this.button4.Name = "button4";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties9.BorderRadius = 3;
            stateProperties9.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties9.ForeColor = System.Drawing.Color.White;
            stateProperties9.IconLeftImage = null;
            stateProperties9.IconRightImage = null;
            this.button4.onHoverState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.BorderRadius = 3;
            stateProperties10.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.ForeColor = System.Drawing.Color.White;
            stateProperties10.IconLeftImage = null;
            stateProperties10.IconRightImage = null;
            this.button4.OnPressedState = stateProperties10;
            this.button4.Size = new System.Drawing.Size(123, 36);
            this.button4.TabIndex = 27;
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button4.TextMarginLeft = 0;
            this.button4.UseDefaultRadiusAndThickness = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Location = new System.Drawing.Point(271, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(116, 55);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(55, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "0";
            // 
            // button2
            // 
            this.button2.AllowToggling = false;
            this.button2.AnimationSpeed = 200;
            this.button2.AutoGenerateColors = false;
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackColor1 = System.Drawing.Color.Green;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.button2.ButtonText = "Suivant";
            this.button2.ButtonTextMarginLeft = 0;
            this.button2.ColorContrastOnClick = 45;
            this.button2.ColorContrastOnHover = 45;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.button2.CustomizableEdges = borderEdges6;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.button2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.button2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.button2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.button2.IconMarginLeft = 11;
            this.button2.IconPadding = 10;
            this.button2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.button2.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.button2.IdleBorderRadius = 3;
            this.button2.IdleBorderThickness = 1;
            this.button2.IdleFillColor = System.Drawing.Color.Green;
            this.button2.IdleIconLeftImage = null;
            this.button2.IdleIconRightImage = null;
            this.button2.IndicateFocus = false;
            this.button2.Location = new System.Drawing.Point(398, 13);
            this.button2.Name = "button2";
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.BorderRadius = 3;
            stateProperties11.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties11.BorderThickness = 1;
            stateProperties11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.ForeColor = System.Drawing.Color.White;
            stateProperties11.IconLeftImage = null;
            stateProperties11.IconRightImage = null;
            this.button2.onHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.BorderRadius = 3;
            stateProperties12.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties12.BorderThickness = 1;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.ForeColor = System.Drawing.Color.White;
            stateProperties12.IconLeftImage = null;
            stateProperties12.IconRightImage = null;
            this.button2.OnPressedState = stateProperties12;
            this.button2.Size = new System.Drawing.Size(123, 36);
            this.button2.TabIndex = 26;
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button2.TextMarginLeft = 0;
            this.button2.UseDefaultRadiusAndThickness = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.DoubleBuffered = true;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.dataGridView1.HeaderForeColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(16, 265);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView1.Size = new System.Drawing.Size(1150, 283);
            this.dataGridView1.TabIndex = 30;
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.Green;
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "Actualiser";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges7.BottomLeft = true;
            borderEdges7.BottomRight = true;
            borderEdges7.TopLeft = true;
            borderEdges7.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges7;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton2.IdleBorderRadius = 3;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.Green;
            this.bunifuButton2.IdleIconLeftImage = null;
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(12, 210);
            this.bunifuButton2.Name = "bunifuButton2";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties13.BorderRadius = 3;
            stateProperties13.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties13.BorderThickness = 1;
            stateProperties13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties13.ForeColor = System.Drawing.Color.White;
            stateProperties13.IconLeftImage = null;
            stateProperties13.IconRightImage = null;
            this.bunifuButton2.onHoverState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties14.BorderRadius = 3;
            stateProperties14.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties14.BorderThickness = 1;
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties14.ForeColor = System.Drawing.Color.White;
            stateProperties14.IconLeftImage = null;
            stateProperties14.IconRightImage = null;
            this.bunifuButton2.OnPressedState = stateProperties14;
            this.bunifuButton2.Size = new System.Drawing.Size(149, 49);
            this.bunifuButton2.TabIndex = 31;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuMaterialTextbox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuMaterialTextbox1.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Enabled = false;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Century Gothic", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox1.HintText = "";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.Black;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineThickness = 5;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(453, -2);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.MaxLength = 32767;
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(303, 65);
            this.bunifuMaterialTextbox1.TabIndex = 32;
            this.bunifuMaterialTextbox1.Text = "Validation de Congé";
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // valid_conge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1179, 560);
            this.Controls.Add(this.bunifuMaterialTextbox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bunifuButton2);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "valid_conge";
            this.Text = "Validation de Congé";
            this.Load += new System.EventHandler(this.valid_conge_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DateTimePicker tb_date_debut;
        private System.Windows.Forms.DateTimePicker tb_date_demande;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_service;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tb_nm_jour;
        private System.Windows.Forms.TextBox tb_matricule;
        private System.Windows.Forms.DateTimePicker tb_date_fin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_nature;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tb_n_dmande;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_categorie;
        private System.Windows.Forms.TextBox tb_nom;
        private System.Windows.Forms.TextBox tb_prenom;
        private System.Windows.Forms.TextBox tb_search;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton button5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton button6;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton button1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton button3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton button4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton button2;
        private System.Windows.Forms.RadioButton rb_non_valider;
        private System.Windows.Forms.RadioButton rb_valider;
        private Bunifu.Framework.UI.BunifuCustomDataGrid dataGridView1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        private System.Windows.Forms.TextBox textBox1;
    }
}