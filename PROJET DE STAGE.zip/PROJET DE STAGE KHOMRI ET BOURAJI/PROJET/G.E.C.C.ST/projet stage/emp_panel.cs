﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class emp_panel : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);

        public emp_panel()
        {
            InitializeComponent();
        }
        
        void remplir_dgv()
        {
            dataGridView1.Rows.Clear();
            string req = "select * from employe order  by matricule asc";
            SqlCommand cmd = new SqlCommand(req, con);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9));
            }
            con.Close();
        }

        private void emp_panel_Load(object sender, EventArgs e)
        {
            remplir_dgv();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            remplir_dgv();
            panel1.Controls.Clear();
            maj m = new maj()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            remplir_dgv();
            panel1.Controls.Clear();
            modifier_maj m = new modifier_maj()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            remplir_dgv();
            panel1.Controls.Clear();
            supprimer m = new supprimer()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            remplir_dgv();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            remplir_dgv();
        }
    }
}
