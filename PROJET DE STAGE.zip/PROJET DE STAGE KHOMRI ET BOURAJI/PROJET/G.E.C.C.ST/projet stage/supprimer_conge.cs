﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class supprimer_conge : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string ind;
        string mn;

        public supprimer_conge()
        {
            InitializeComponent();
        }

        void all()
        {
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule ";
            SqlCommand cmd = new SqlCommand(req, con);

            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
            lec.Close();
            con.Close();
        }

       

        void matricule_()
        {
            dataGridView1.Rows.Clear();
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule where c.matricule=@vd order by c.num_demande asc ";
            SqlCommand cmd = new SqlCommand(req, con);
            mn = null;
            cmd.Parameters.AddWithValue("@vd", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();

                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
            if (mn == null)
            {
                MessageBox.Show("N'existe pas");
            }
            lec.Close();
            con.Close();
        }



        private void supprimer_conge_Load(object sender, EventArgs e)
        {
            all();
        }

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }


        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Il faut Rechercher par NUMERO DE DEMANDE d'abord ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (MessageBox.Show("vous voulez supprimer ce demande ?", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string req = "delete from congé where num_demande =@matr ";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@matr", textBox1.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                dataGridView1.Rows.Clear();
                MessageBox.Show("Ce demande a été supprimer .");
                textBox1.Clear();
                all();
            }
            textBox1.Clear();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule where c.num_demande=@vd";
            SqlCommand cmd = new SqlCommand(req, con);
            mn = null;
            cmd.Parameters.AddWithValue("@vd", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
            if (mn == null)
            {
                MessageBox.Show("Ce demande n'existe pas","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            lec.Close();
            con.Close();
        }
    }
 }
