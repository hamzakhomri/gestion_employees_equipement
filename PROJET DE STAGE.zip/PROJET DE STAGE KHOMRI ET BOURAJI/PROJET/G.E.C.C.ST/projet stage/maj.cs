﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class maj : Form
    {

        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);

        public maj()
        {
            InitializeComponent();
        }

        private void clear()
        {
            matricule.Clear(); nom.Clear(); prenom.Clear();
            stade.Clear(); tel.Text = "+212".ToString(); tb_embauche.Text = DateTime.Now.ToString();
            tb_retraite.Text = DateTime.Now.ToString(); tel.Clear(); matricule.Focus();
        }


        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (matricule.Text == "" || nom.Text == "" || prenom.Text == "" || categorie.Text == "" || service.Text == "" || lieu.Text == "" || stade.Text == "" || tel.Text == "")
            {
                MessageBox.Show("Les chemps sont vide. il faut saisie d'abord tout les données", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (tel.Text.Length == 13 && char.IsNumber(tel.Text, tel.Text.Length - 9) && char.IsNumber(tel.Text, tel.Text.Length - 8) && char.IsNumber(tel.Text, tel.Text.Length - 7) && char.IsNumber(tel.Text, tel.Text.Length - 6) && char.IsNumber(tel.Text, tel.Text.Length - 5) && char.IsNumber(tel.Text, tel.Text.Length - 4) && char.IsNumber(tel.Text, tel.Text.Length - 3) && char.IsNumber(tel.Text, tel.Text.Length - 2) && char.IsNumber(tel.Text, tel.Text.Length - 1))
                {
                    if (matricule.Text.Length < 6)
                    {
                        string req = "insert into employe values (@matricule,@nom,@prenom,@categorie,@service,@lieu,@stade,@embauche,@retraite,@tel)";
                        SqlCommand cmd = new SqlCommand(req, con);
                        cmd.Parameters.AddWithValue("@matricule", matricule.Text);
                        cmd.Parameters.AddWithValue("@nom", nom.Text);
                        cmd.Parameters.AddWithValue("@prenom", prenom.Text);
                        cmd.Parameters.AddWithValue("@categorie", categorie.Text);
                        cmd.Parameters.AddWithValue("@service", service.Text);
                        cmd.Parameters.AddWithValue("@lieu", lieu.Text);
                        cmd.Parameters.AddWithValue("@stade", stade.Text);
                        cmd.Parameters.AddWithValue("@embauche", Convert.ToDateTime(tb_embauche.Text));
                        cmd.Parameters.AddWithValue("@retraite", Convert.ToDateTime(tb_retraite.Text));
                        cmd.Parameters.AddWithValue("@tel", tel.Text);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        clear();

                        MessageBox.Show("L'ajoute a ete effectue .", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Format de Matricule est incorrect", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                    MessageBox.Show("Format de Numero de Telephone est incorrect", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
