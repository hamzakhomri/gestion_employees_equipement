﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class modifier_maj : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mon;
        public modifier_maj()
        {
            InitializeComponent();
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            if (rechercher.Text == "")
            { MessageBox.Show("Il faut Remplir la zone de recherche", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            else
            {
                mon = null;

                string req = "select * from employe where matricule= @rechercher";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@rechercher", rechercher.Text);
                con.Open();
                SqlDataReader lec = cmd.ExecuteReader();
                while (lec.Read())
                {
                    mon = lec.GetValue(0).ToString();
                    matricule.Text = lec.GetValue(0).ToString();
                    nom.Text = lec.GetValue(1).ToString();
                    prenom.Text = lec.GetValue(2).ToString();
                    yu.Text = lec.GetValue(3).ToString();
                    service.Text = lec.GetValue(4).ToString();
                    lien.Text = lec.GetValue(5).ToString();
                    stade.Text = lec.GetValue(6).ToString();
                    tb_embauche.Text = lec.GetValue(7).ToString();
                     tb_retraite.Text =lec.GetValue(8).ToString();
                    tel.Text = lec.GetValue(9).ToString();
                }
                con.Close();
                if (mon == null)
                {
                    MessageBox.Show("Ce employe n'existe pas .", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            matricule.Focus();
        }

        private void modifierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            modifier_maj m = new modifier_maj();
            m.Show();
            this.Close();


        }
        private void clear()
        {
            matricule.Clear(); nom.Clear(); prenom.Clear(); yu.Text = ""; service.Text=""; lien.Text="";
            stade.Clear(); tel.Text = "+212".ToString(); tb_embauche.Text = DateTime.Now.ToString();
            tb_retraite.Text = DateTime.Now.ToString();  rechercher.Focus();
        }

        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            supprimer s = new supprimer();
            s.Show();
            this.Close();
        }

        private void supprimerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            maj m = new maj();
            m.Show();
            this.Close();
        }

        private void retourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            employe e_ = new employe();
            e_.Show();
            this.Close();
        }

        private void ajouterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            maj m = new maj();
            m.Show();
            this.Close();
        }

        private void modifierToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            modifier_maj m = new modifier_maj();
            m.Show();
            this.Close();
        }

        private void supprimerToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            supprimer s = new supprimer();
            s.Show();
            this.Close();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            if (matricule.Text == "" || nom.Text == "" || prenom.Text == "" || yu.Text == "" || service.Text == "" || lien.Text == "" || stade.Text == "" || tel.Text == "")
            {
                MessageBox.Show("Il faut remplir tout les chemps ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            if (rechercher.Text == "")
            {
                MessageBox.Show("Il faut Rechercher si ce employé existe ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {


                if (tel.Text.Length == 13 && char.IsNumber(tel.Text, tel.Text.Length - 9) && char.IsNumber(tel.Text, tel.Text.Length - 8) && char.IsNumber(tel.Text, tel.Text.Length - 7) && char.IsNumber(tel.Text, tel.Text.Length - 6) && char.IsNumber(tel.Text, tel.Text.Length - 5) && char.IsNumber(tel.Text, tel.Text.Length - 4) && char.IsNumber(tel.Text, tel.Text.Length - 3) && char.IsNumber(tel.Text, tel.Text.Length - 2) && char.IsNumber(tel.Text, tel.Text.Length - 1))
                {
                    if (MessageBox.Show("vous voulez Modifier les nformations de ce employé ?", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        string req = "update employe set   nom= @nom,prenom= @prenom,categorie= @categorie,serviice= @service,lieu= @lieu,stade= @stade,date_embauche= @embauche ,date_retraite= @rtraite,tel= @tel where matricule=@rech ";
                        SqlCommand cmd = new SqlCommand(req, con);
                        cmd.Parameters.AddWithValue("@rech", rechercher.Text);
                        cmd.Parameters.AddWithValue("@nom", nom.Text);
                        cmd.Parameters.AddWithValue("@prenom", prenom.Text);
                        cmd.Parameters.AddWithValue("@categorie", yu.Text);
                        cmd.Parameters.AddWithValue("@service", service.Text);
                        cmd.Parameters.AddWithValue("@lieu", lien.Text);
                        cmd.Parameters.AddWithValue("@stade", stade.Text);
                        cmd.Parameters.AddWithValue("@embauche", Convert.ToDateTime(tb_embauche.Text));
                        cmd.Parameters.AddWithValue("@rtraite", Convert.ToDateTime(tb_retraite.Text));
                        cmd.Parameters.AddWithValue("@tel", double.Parse(tel.Text));

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    else
                    {
                       
                        MessageBox.Show("La Modification a été annuler", "Verifications", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                else
                {
                    MessageBox.Show("Le numéro de telephone est incorrect. EX:+212600000000", "Verifications", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            clear();
            MessageBox.Show("La modification a ete effectue .");
            matricule.Focus();
          
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void modifier_maj_Load(object sender, EventArgs e)
        {
            rechercher.Focus();
        }
    }

       
    }