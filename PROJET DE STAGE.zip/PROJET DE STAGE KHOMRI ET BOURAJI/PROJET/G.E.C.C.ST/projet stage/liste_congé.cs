﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class liste_congé : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
       public string mn;

        public liste_congé()
        {
            InitializeComponent();
        }

        void act ()
        {
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule ";
            SqlCommand cmd = new SqlCommand(req, con);

            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
            count.Text = dataGridView1.RowCount.ToString();
            lec.Close();
            con.Close();
        }
        private void liste_congé_Load(object sender, EventArgs e)
        {
            act();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            con.Open();
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,e.entite,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule where c.validaton='valider'";
            SqlCommand cmd = new SqlCommand(req, con);
           
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
              
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11), lec.GetValue(12)) ;
            }
            lec.Close();
            con.Close();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            string vl = "NonValider";
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,e.entite,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule where c.validaton=@vd  ";
            SqlCommand cmd = new SqlCommand(req, con);

            cmd.Parameters.AddWithValue("@vd", vl);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11), lec.GetValue(12));
            }
            lec.Close();
            con.Close();
        }
        
        void num_demande()
        {
           dataGridView1.Rows.Clear();
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule where c.num_demande=@vd order by c.num_demande asc ";
            SqlCommand cmd = new SqlCommand(req, con);
            mn = null;
            cmd.Parameters.AddWithValue("@vd", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();
                
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
            if (mn == null)
            {
                MessageBox.Show("N'existe pas");
            }
            lec.Close();
            con.Close();
        }

        void matricule_()
        {
            dataGridView1.Rows.Clear();
            string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour,c.validaton from congé c inner join employe e on c.matricule=e.matricule where c.matricule=@vd order by c.num_demande asc ";
            SqlCommand cmd = new SqlCommand(req, con);
            mn = null;
            cmd.Parameters.AddWithValue("@vd", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();
               
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11));
            }
            if (mn == null)
            {
                MessageBox.Show("N'existe pas");
            }
            lec.Close();
            con.Close();
        }

        private void bunifuButton1_Click_1(object sender, EventArgs e)
        {
            if (n_demande.Checked == false && matricule.Checked == false)
            {
                MessageBox.Show("coché D'abord le type de Recherche ","",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }

            if(n_demande.Checked == true)
            {
                num_demande();
            }

            if (matricule.Checked == true)
            {
                matricule_();
            }
            textBox1.Clear();
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            textBox1.Clear();
            act();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelApp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        xcelApp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
            }
        }
    }
}
