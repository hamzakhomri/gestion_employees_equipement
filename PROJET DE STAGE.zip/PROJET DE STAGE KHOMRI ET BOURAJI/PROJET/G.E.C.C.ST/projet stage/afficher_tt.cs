﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class afficher_tt : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mon;

        public afficher_tt()
        {
            InitializeComponent();
        }

        void matricule()
        {
            string req = " select * from employe where matricule =@matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
             
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9));
            }
            con.Close();
            if (mon == null)
            {
                MessageBox.Show("Ce employe n'existe pas .");
            }
        }
        void nom()
        {
            string req = " select * from employe where nom =@nom";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@nom", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9));
            }
            con.Close();
            if (mon == null)
            {
                MessageBox.Show("Ce employe n'existe pas .");
            }
        }
        void prenom()
        {
           
            string req = " select * from employe where prenom =@prenom";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@prenom", textBox1.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9));
            }
            con.Close();
            if (mon == null)
            {
                MessageBox.Show("Ce employe n'existe pas .");
            }
        }

        private void afficher_tt_Load(object sender, EventArgs e)
        {
            string req = "select * from employe order  by matricule asc";
            SqlCommand cmd = new SqlCommand(req, con);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9));
            }
            con.Close();
         
        }

        private void acueilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil a = new accueil();
            a.Show();
            this.Close();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                MessageBox.Show("la zone de texte et vide .");
            }

                if (rb_matricule.Checked == true)
            { dataGridView1.Rows.Clear();
                matricule(); }

            else if (rb_prenom.Checked == true)
            { dataGridView1.Rows.Clear(); prenom(); }

            else if (rb_nom.Checked == true)
            { dataGridView1.Rows.Clear(); nom(); }
            else
            {
                MessageBox.Show("Recherche invalide");
            }
        }

        private void retourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            employe e_ = new employe();
            e_.Show();
            this.Close();
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
dataGridView1.Rows.Clear();

            textBox1.Clear();
            string req = "select * from employe";
            SqlCommand cmd = new SqlCommand(req, con);
            con.Open();
            SqlDataReader lect = cmd.ExecuteReader();
            while (lect.Read())
            {
                dataGridView1.Rows.Add(lect.GetValue(0), lect.GetValue(1), lect.GetValue(2), lect.GetValue(3), lect.GetValue(4), lect.GetValue(5), lect.GetValue(6), lect.GetValue(7), lect.GetValue(8), lect.GetValue(9));
            }
            con.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelApp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        xcelApp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
            }
        }

        private void deconnecterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter","Questions",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
