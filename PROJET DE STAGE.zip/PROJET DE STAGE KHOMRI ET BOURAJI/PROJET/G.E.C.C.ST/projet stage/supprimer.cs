﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class supprimer : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        static string mon;
        public supprimer()
        {
            InitializeComponent();
        }

        private void supp_compte()
        {
            string req = "delete from compte where matricule = @matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", rechercher.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

       private void suppr_conge()
        {
            string req = "delete from congé where matricule =@matr ";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", rechercher.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void suppr_emp()
        {
            string req = "delete from employe  where matricule=@rech  ";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@rech", rechercher.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            clear();
            MessageBox.Show("La supression a ete effectue.");
            rechercher.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            mon = null;
            if (rechercher.Text == "")
            { MessageBox.Show("Il faut Remplir tout les zones", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                con.Open();
                string req = "select * from employe where matricule= @rechercher";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@rechercher", rechercher.Text);
                SqlDataReader lec = cmd.ExecuteReader();
                while (lec.Read())
                {
                    mon = lec.GetValue(0).ToString();
                    matricule.Text = lec.GetValue(0).ToString();
                    nom.Text = lec.GetValue(1).ToString();
                    prenom.Text = lec.GetValue(2).ToString();
                    categorie.Text = lec.GetValue(3).ToString();
                    service.Text = lec.GetValue(4).ToString();
                    lien.Text = lec.GetValue(5).ToString();
                    stade.Text = lec.GetValue(6).ToString();
                    tb_embauche.Text = lec.GetValue(7).ToString();
                    tb_retraite.Text = lec.GetValue(8).ToString();
                    tel.Text = lec.GetValue(9).ToString();
                }
                if (mon==null)
                {
                    MessageBox.Show("Ce matricule n'existe pas .");
                    return;
                }

                lec.Close();
                con.Close();
            }
        }
        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            maj m = new maj();
            m.Show();
            this.Close();
        }

        private void modifierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            modifier_maj mm = new modifier_maj();
            mm.Show();
            this.Close();
        }

        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            supprimer s = new supprimer();
            s.Show();
            this.Close();
        }

        private void clear()
        {
            matricule.Clear(); nom.Clear(); prenom.Clear(); categorie.Text=""; service.Clear(); lien.Clear();
            stade.Clear();  tel.Text = "+212".ToString(); tb_embauche.Text = DateTime.Now.ToString();
            tb_retraite.Text = DateTime.Now.ToString();
        }

        private void accueilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil a = new accueil();
            a.Show();
            this.Close();
        }

        private void retourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            employe e_ = new employe();
            e_.Show();
            this.Close();
        }


      
     
        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (rechercher.Text == "")
            {
                MessageBox.Show("Il faut Rechercher si Ce employe existe ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (matricule.Text=="")
            {
                MessageBox.Show("Il faut trouver d'abord si ce eploye existe ou pas .", "", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            }
             if (MessageBox.Show("Si vous Voulez Supprimer ce employé vas supprimer aussi Les Congés", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                supp_compte();
                suppr_conge();
                suppr_emp();
            }
            
            matricule.Focus();
        }

      

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void supprimer_Load(object sender, EventArgs e)
        {
        }
    }
}
