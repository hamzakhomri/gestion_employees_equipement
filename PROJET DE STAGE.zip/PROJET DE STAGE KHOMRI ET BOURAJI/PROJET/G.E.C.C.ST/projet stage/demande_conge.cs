﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class demande_conge : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        static SqlConnection con = new SqlConnection(cnx);
        string mn;
        supprimer_conge s = new supprimer_conge();


        void clear ()
        {
            tb_matricule.Clear();
            tb_nom.Clear();
            tb_prenom.Clear();
            tb_categorie.Clear();
            tb_service.Clear();
            
            n_demande.Clear();
            tb_date_demande.Text = DateTime.Now.ToString();
            tb_date_debut.Text = DateTime.Now.ToString();
            tb_nm_jour.Clear();
            tb_matricule.Focus();
        }


        void search()
        {
            con.Open();
            mn = null;

            string req = "select nom,prenom,categorie,serviice from employe where matricule=@matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_matricule.Text);
            
            SqlDataReader lec = cmd.ExecuteReader();

            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();
                tb_nom.Text = lec.GetValue(0).ToString();
                tb_prenom.Text = lec.GetValue(1).ToString();
                tb_categorie.Text = lec.GetValue(2).ToString();
                tb_service.Text = lec.GetValue(3).ToString();
            }
        
            con.Close();

            if (mn == null)
            {
                MessageBox.Show("Ce employe N'existe pas", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        void search_cong()
        { con.Open();
         
            mn = null;
            string req = "select matricule from congé where nmb_jour >30";
            SqlCommand cmd = new SqlCommand(req, con);
           
            cmd.Parameters.AddWithValue("@matr", tb_matricule.Text);
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(0).ToString();
                
                    if (MessageBox.Show("Ce Employe est déja Demander Un Congé. Vous voulez Supprimé l'ancien Demande?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        s.Show();
                    }
            }
            lec.Close();
            con.Close();
            if (mn==null)
            {
                search();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (tb_matricule.Text == "")
            {
                MessageBox.Show("Il faut Remplir la zone de recherche d'abord");
                return;
            }

            //search_cong();
            dem();
            search();
        }

        void dem()
        {
            string req = "select max(num_demande + 1) from congé ";
            con.Open();
            SqlCommand cmd = new SqlCommand(req, con);
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                n_demande.Text = lec.GetValue(0).ToString();
            }
            lec.Close();
            con.Close();
         }

        public demande_conge()
        {
            InitializeComponent();
        }
        
        private void demndéCongéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }



        private void demande_conge_Load(object sender, EventArgs e)
        {
            
            dataGridView1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tb_matricule.Clear();
            tb_nom.Clear();
            tb_prenom.Clear();
            tb_categorie.Clear();
            tb_service.Clear();
            
            n_demande.Clear();
            tb_date_demande.Text = DateTime.Now.ToString();
            tb_date_debut.Text = DateTime.Now.ToString();
            tb_nm_jour.Clear();
        }

      

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (tb_matricule.Text == "")
            {
                MessageBox.Show("Il faut rechercher si ce employe existe ou n'existe pas.","",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
       
            if (tb_nom.Text == "")
            {
                MessageBox.Show("Il faut Trouvé d'abord l'employe");
            }

            if( tb_nature.Text == "" || tb_nm_jour.Text=="")
            {
                MessageBox.Show("Il faut Remplir tout les zones de textes d'abord","",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }


            //if (int.Parse(tb_nm_jour.Text)<=30)
            //{
            //    MessageBox.Show("Les Nombres des Jours et non autorisé ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}
       
            else
            {
                DateTime df = tb_date_debut.Value.AddDays(int.Parse(tb_nm_jour.Text));
                tb_date_demande.Text = DateTime.Now.ToString();
                string req = "insert into congé (matricule,nature_conge,date_demande,date_debut,date_fin,nmb_jour) values (@matricule,@nature,@date_demande,@date_debut,@date_fin ,@nmbr_jour)";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@matricule", tb_matricule.Text);
                //cmd.Parameters.AddWithValue("@num", int.Parse(n_demande.Text));
                cmd.Parameters.AddWithValue("@nature", tb_nature.Text);
                cmd.Parameters.AddWithValue("@date_demande", DateTime.Parse(tb_date_demande.Text));
                cmd.Parameters.AddWithValue("@date_debut", DateTime.Parse(tb_date_debut.Text));
                cmd.Parameters.AddWithValue("@date_fin", df);
                cmd.Parameters.AddWithValue("@nmbr_jour", int.Parse(tb_nm_jour.Text));
                //cmd.Parameters.AddWithValue("@validation",textBox1.Text);
                //datefin = datedebut.value.add.day(tb_categorie.)
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("la demande a ete envoyer");

                clear();
            }
        }
        
     

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            clear();
        }

       
    }
}
