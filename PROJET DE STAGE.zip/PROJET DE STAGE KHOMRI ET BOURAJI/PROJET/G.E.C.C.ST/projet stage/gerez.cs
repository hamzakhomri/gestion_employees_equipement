﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class gerez : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mn;

        public gerez()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mn = null;
            if (tb_adresse.Text == "" && tb_mdp.Text=="")
            {
                MessageBox.Show("La recherhce n'été pas complet", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
                string req = "select * from compte where logiin=@login and mdp = @mdp";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@login", tb_adresse.Text);
                cmd.Parameters.AddWithValue("@mdp", tb_mdp.Text);
                con.Open();
                SqlDataReader lec = cmd.ExecuteReader();
                while (lec.Read())
                {
                    mn = lec.GetValue(0).ToString();
                tb_matricule.Text = lec.GetValue(0).ToString();
                tb_email.Text = lec.GetValue(1).ToString();
                tb_adresse.Text = lec.GetValue(2).ToString();
                groupBox8.Visible = true;
            }
            lec.Close();
            con.Close();
            if (mn==null)
            {
                MessageBox.Show("Ce Compte est introuvable" , "", MessageBoxButtons.OK, MessageBoxIcon.Error );
            }
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
               if (MessageBox.Show("vous voulez Supprimer Ce Compte ?", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string req = "delete from compte where Matricule=@matr";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@matr", tb_matricule.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                tb_adresse.Clear();         tb_email.Clear();          tb_matricule.Clear();        tb_mdp.Clear();
                MessageBox.Show("Ce Compte a ete supprimer", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            tb_matricule.Focus();
        }

        private void retourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            this.Close();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            string s = tb_email.Text.ToUpper();
            if (tb_email.Text.Length <=10)
            {
                MessageBox.Show("Votre Gmail est incorect,Il doit Términer par @gmail.com", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (s.Substring(s.Length  -10, 10) == "@GMAIL.COM" && s.Length <= 25  )
            {
                if (MessageBox.Show("vous voules Vraiment Modifier Les données de votre compte ?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string req = "update compte set email=@em , logiin = @log , mdp=@mdp where Matricule = @matr";
                    SqlCommand cmd = new SqlCommand(req, con);
                    cmd.Parameters.AddWithValue("@matr", tb_matricule.Text);

                    cmd.Parameters.AddWithValue("@em", tb_email.Text);
                    cmd.Parameters.AddWithValue("@log", tb_adresse.Text);
                    cmd.Parameters.AddWithValue("@mdp", tb_mdp.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("La modification a été effectué en succés", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else MessageBox.Show("Votre Gmail est incorect,Il doit Términer par @gmail.com","",MessageBoxButtons.OK,MessageBoxIcon.Error);
            tb_matricule.Focus();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void gerez_Load(object sender, EventArgs e)
        {
            groupBox8.Visible = false;
        }
    }
}