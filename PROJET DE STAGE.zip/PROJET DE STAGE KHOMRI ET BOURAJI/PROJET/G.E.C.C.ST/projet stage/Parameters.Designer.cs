﻿namespace projet_stage
{
    partial class Parameters
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Parameters));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_matr = new System.Windows.Forms.TextBox();
            this.bunifuUserControl1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.tb_conf = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tb_mdp = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tb_adresse = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tb_email = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuUserControl1_ = new Bunifu.UI.WinForms.BunifuUserControl();
            this.bunifuUserControl2 = new Bunifu.UI.WinForms.BunifuUserControl();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuUserControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matricule : ";
            // 
            // tb_matr
            // 
            this.tb_matr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tb_matr.Location = new System.Drawing.Point(101, 110);
            this.tb_matr.Name = "tb_matr";
            this.tb_matr.Size = new System.Drawing.Size(168, 20);
            this.tb_matr.TabIndex = 1;
            // 
            // bunifuUserControl1
            // 
            this.bunifuUserControl1.Controls.Add(this.label3);
            this.bunifuUserControl1.Controls.Add(this.label2);
            this.bunifuUserControl1.Controls.Add(this.bunifuFlatButton2);
            this.bunifuUserControl1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuUserControl1.Controls.Add(this.tb_conf);
            this.bunifuUserControl1.Controls.Add(this.tb_mdp);
            this.bunifuUserControl1.Controls.Add(this.tb_adresse);
            this.bunifuUserControl1.Controls.Add(this.tb_email);
            this.bunifuUserControl1.Controls.Add(this.bunifuUserControl1_);
            this.bunifuUserControl1.Location = new System.Drawing.Point(-36, 137);
            this.bunifuUserControl1.Name = "bunifuUserControl1";
            this.bunifuUserControl1.Size = new System.Drawing.Size(728, 365);
            this.bunifuUserControl1.TabIndex = 4;
            this.bunifuUserControl1.TabStop = false;
            this.bunifuUserControl1.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(83, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(209, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "confirmer votre mot de passe";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(83, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Entrer un mot de passe";
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Active = false;
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Sauvegarder";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(203, 267);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.Lime;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(171, 55);
            this.bunifuFlatButton2.TabIndex = 14;
            this.bunifuFlatButton2.Text = "Sauvegarder";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.BorderRadius = 50;
            this.bunifuPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuPictureBox1.Image")));
            this.bunifuPictureBox1.IsCircle = true;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(341, 15);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(225, 225);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 9;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
            // 
            // tb_conf
            // 
            this.tb_conf.AcceptsReturn = false;
            this.tb_conf.AcceptsTab = false;
            this.tb_conf.AnimationSpeed = 200;
            this.tb_conf.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_conf.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_conf.BackColor = System.Drawing.Color.Transparent;
            this.tb_conf.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_conf.BackgroundImage")));
            this.tb_conf.BorderColorActive = System.Drawing.Color.Green;
            this.tb_conf.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_conf.BorderColorHover = System.Drawing.Color.Lime;
            this.tb_conf.BorderColorIdle = System.Drawing.Color.Black;
            this.tb_conf.BorderRadius = 4;
            this.tb_conf.BorderThickness = 1;
            this.tb_conf.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_conf.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_conf.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_conf.DefaultText = "";
            this.tb_conf.FillColor = System.Drawing.Color.White;
            this.tb_conf.HideSelection = true;
            this.tb_conf.IconLeft = null;
            this.tb_conf.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_conf.IconPadding = 10;
            this.tb_conf.IconRight = null;
            this.tb_conf.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_conf.Lines = new string[0];
            this.tb_conf.Location = new System.Drawing.Point(84, 205);
            this.tb_conf.MaxLength = 32767;
            this.tb_conf.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_conf.Modified = false;
            this.tb_conf.Multiline = false;
            this.tb_conf.Name = "tb_conf";
            stateProperties1.BorderColor = System.Drawing.Color.Green;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_conf.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_conf.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.Lime;
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_conf.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Black;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_conf.OnIdleState = stateProperties4;
            this.tb_conf.PasswordChar = '*';
            this.tb_conf.PlaceholderForeColor = System.Drawing.Color.Black;
            this.tb_conf.PlaceholderText = "Comfirmer votre Mot de passe";
            this.tb_conf.ReadOnly = false;
            this.tb_conf.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_conf.SelectedText = "";
            this.tb_conf.SelectionLength = 0;
            this.tb_conf.SelectionStart = 0;
            this.tb_conf.ShortcutsEnabled = true;
            this.tb_conf.Size = new System.Drawing.Size(221, 35);
            this.tb_conf.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_conf.TabIndex = 13;
            this.tb_conf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_conf.TextMarginBottom = 0;
            this.tb_conf.TextMarginLeft = 5;
            this.tb_conf.TextMarginTop = 0;
            this.tb_conf.TextPlaceholder = "Comfirmer votre Mot de passe";
            this.tb_conf.UseSystemPasswordChar = false;
            this.tb_conf.WordWrap = true;
            // 
            // tb_mdp
            // 
            this.tb_mdp.AcceptsReturn = false;
            this.tb_mdp.AcceptsTab = false;
            this.tb_mdp.AnimationSpeed = 200;
            this.tb_mdp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_mdp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_mdp.BackColor = System.Drawing.Color.Transparent;
            this.tb_mdp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_mdp.BackgroundImage")));
            this.tb_mdp.BorderColorActive = System.Drawing.Color.Green;
            this.tb_mdp.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_mdp.BorderColorHover = System.Drawing.Color.Lime;
            this.tb_mdp.BorderColorIdle = System.Drawing.Color.Black;
            this.tb_mdp.BorderRadius = 4;
            this.tb_mdp.BorderThickness = 1;
            this.tb_mdp.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_mdp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mdp.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_mdp.DefaultText = "";
            this.tb_mdp.FillColor = System.Drawing.Color.White;
            this.tb_mdp.HideSelection = true;
            this.tb_mdp.IconLeft = null;
            this.tb_mdp.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mdp.IconPadding = 10;
            this.tb_mdp.IconRight = null;
            this.tb_mdp.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mdp.Lines = new string[0];
            this.tb_mdp.Location = new System.Drawing.Point(84, 145);
            this.tb_mdp.MaxLength = 32767;
            this.tb_mdp.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_mdp.Modified = false;
            this.tb_mdp.Multiline = false;
            this.tb_mdp.Name = "tb_mdp";
            stateProperties5.BorderColor = System.Drawing.Color.Green;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_mdp.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_mdp.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.Lime;
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_mdp.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Black;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_mdp.OnIdleState = stateProperties8;
            this.tb_mdp.PasswordChar = '*';
            this.tb_mdp.PlaceholderForeColor = System.Drawing.Color.Black;
            this.tb_mdp.PlaceholderText = "Entrer le mot de passe";
            this.tb_mdp.ReadOnly = false;
            this.tb_mdp.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_mdp.SelectedText = "";
            this.tb_mdp.SelectionLength = 0;
            this.tb_mdp.SelectionStart = 0;
            this.tb_mdp.ShortcutsEnabled = true;
            this.tb_mdp.Size = new System.Drawing.Size(221, 35);
            this.tb_mdp.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_mdp.TabIndex = 12;
            this.tb_mdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_mdp.TextMarginBottom = 0;
            this.tb_mdp.TextMarginLeft = 5;
            this.tb_mdp.TextMarginTop = 0;
            this.tb_mdp.TextPlaceholder = "Entrer le mot de passe";
            this.tb_mdp.UseSystemPasswordChar = false;
            this.tb_mdp.WordWrap = true;
            // 
            // tb_adresse
            // 
            this.tb_adresse.AcceptsReturn = false;
            this.tb_adresse.AcceptsTab = false;
            this.tb_adresse.AnimationSpeed = 200;
            this.tb_adresse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_adresse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_adresse.BackColor = System.Drawing.Color.Transparent;
            this.tb_adresse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_adresse.BackgroundImage")));
            this.tb_adresse.BorderColorActive = System.Drawing.Color.Green;
            this.tb_adresse.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_adresse.BorderColorHover = System.Drawing.Color.Lime;
            this.tb_adresse.BorderColorIdle = System.Drawing.Color.Black;
            this.tb_adresse.BorderRadius = 4;
            this.tb_adresse.BorderThickness = 1;
            this.tb_adresse.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_adresse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_adresse.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_adresse.DefaultText = "";
            this.tb_adresse.FillColor = System.Drawing.Color.White;
            this.tb_adresse.HideSelection = true;
            this.tb_adresse.IconLeft = null;
            this.tb_adresse.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_adresse.IconPadding = 10;
            this.tb_adresse.IconRight = null;
            this.tb_adresse.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_adresse.Lines = new string[0];
            this.tb_adresse.Location = new System.Drawing.Point(84, 74);
            this.tb_adresse.MaxLength = 32767;
            this.tb_adresse.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_adresse.Modified = false;
            this.tb_adresse.Multiline = false;
            this.tb_adresse.Name = "tb_adresse";
            stateProperties9.BorderColor = System.Drawing.Color.Green;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_adresse.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_adresse.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.Lime;
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_adresse.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Black;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_adresse.OnIdleState = stateProperties12;
            this.tb_adresse.PasswordChar = '\0';
            this.tb_adresse.PlaceholderForeColor = System.Drawing.Color.Black;
            this.tb_adresse.PlaceholderText = "Entrer votre Adersse";
            this.tb_adresse.ReadOnly = false;
            this.tb_adresse.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_adresse.SelectedText = "";
            this.tb_adresse.SelectionLength = 0;
            this.tb_adresse.SelectionStart = 0;
            this.tb_adresse.ShortcutsEnabled = true;
            this.tb_adresse.Size = new System.Drawing.Size(221, 35);
            this.tb_adresse.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_adresse.TabIndex = 11;
            this.tb_adresse.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_adresse.TextMarginBottom = 0;
            this.tb_adresse.TextMarginLeft = 5;
            this.tb_adresse.TextMarginTop = 0;
            this.tb_adresse.TextPlaceholder = "Entrer votre Adersse";
            this.tb_adresse.UseSystemPasswordChar = false;
            this.tb_adresse.WordWrap = true;
            // 
            // tb_email
            // 
            this.tb_email.AcceptsReturn = false;
            this.tb_email.AcceptsTab = false;
            this.tb_email.AnimationSpeed = 200;
            this.tb_email.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_email.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_email.BackColor = System.Drawing.Color.Transparent;
            this.tb_email.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_email.BackgroundImage")));
            this.tb_email.BorderColorActive = System.Drawing.Color.Green;
            this.tb_email.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_email.BorderColorHover = System.Drawing.Color.Lime;
            this.tb_email.BorderColorIdle = System.Drawing.Color.Black;
            this.tb_email.BorderRadius = 4;
            this.tb_email.BorderThickness = 1;
            this.tb_email.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_email.DefaultText = "";
            this.tb_email.FillColor = System.Drawing.Color.White;
            this.tb_email.HideSelection = true;
            this.tb_email.IconLeft = null;
            this.tb_email.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.IconPadding = 10;
            this.tb_email.IconRight = null;
            this.tb_email.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.Lines = new string[0];
            this.tb_email.Location = new System.Drawing.Point(84, 15);
            this.tb_email.MaxLength = 32767;
            this.tb_email.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_email.Modified = false;
            this.tb_email.Multiline = false;
            this.tb_email.Name = "tb_email";
            stateProperties13.BorderColor = System.Drawing.Color.Green;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_email.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.Lime;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Black;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnIdleState = stateProperties16;
            this.tb_email.PasswordChar = '\0';
            this.tb_email.PlaceholderForeColor = System.Drawing.Color.Black;
            this.tb_email.PlaceholderText = "Entrer votre Email";
            this.tb_email.ReadOnly = false;
            this.tb_email.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_email.SelectedText = "";
            this.tb_email.SelectionLength = 0;
            this.tb_email.SelectionStart = 0;
            this.tb_email.ShortcutsEnabled = true;
            this.tb_email.Size = new System.Drawing.Size(221, 35);
            this.tb_email.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_email.TabIndex = 10;
            this.tb_email.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_email.TextMarginBottom = 0;
            this.tb_email.TextMarginLeft = 5;
            this.tb_email.TextMarginTop = 0;
            this.tb_email.TextPlaceholder = "Entrer votre Email";
            this.tb_email.UseSystemPasswordChar = false;
            this.tb_email.WordWrap = true;
            // 
            // bunifuUserControl1_
            // 
            this.bunifuUserControl1_.AllowAnimations = false;
            this.bunifuUserControl1_.AllowBorderColorChanges = false;
            this.bunifuUserControl1_.AllowMouseEffects = false;
            this.bunifuUserControl1_.AnimationSpeed = 200;
            this.bunifuUserControl1_.BackColor = System.Drawing.Color.Transparent;
            this.bunifuUserControl1_.BackgroundColor = System.Drawing.SystemColors.Control;
            this.bunifuUserControl1_.BorderColor = System.Drawing.Color.Black;
            this.bunifuUserControl1_.BorderRadius = 2;
            this.bunifuUserControl1_.BorderThickness = 2;
            this.bunifuUserControl1_.ColorContrastOnClick = 30;
            this.bunifuUserControl1_.ColorContrastOnHover = 30;
            this.bunifuUserControl1_.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuUserControl1_.Image = null;
            this.bunifuUserControl1_.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuUserControl1_.Location = new System.Drawing.Point(41, -2);
            this.bunifuUserControl1_.Name = "bunifuUserControl1_";
            this.bunifuUserControl1_.ShowBorders = true;
            this.bunifuUserControl1_.Size = new System.Drawing.Size(537, 348);
            this.bunifuUserControl1_.Style = Bunifu.UI.WinForms.BunifuUserControl.UserControlStyles.Flat;
            this.bunifuUserControl1_.TabIndex = 0;
            // 
            // bunifuUserControl2
            // 
            this.bunifuUserControl2.AllowAnimations = false;
            this.bunifuUserControl2.AllowBorderColorChanges = false;
            this.bunifuUserControl2.AllowMouseEffects = false;
            this.bunifuUserControl2.AnimationSpeed = 200;
            this.bunifuUserControl2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuUserControl2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.bunifuUserControl2.BorderColor = System.Drawing.Color.Black;
            this.bunifuUserControl2.BorderRadius = 2;
            this.bunifuUserControl2.BorderThickness = 2;
            this.bunifuUserControl2.ColorContrastOnClick = 30;
            this.bunifuUserControl2.ColorContrastOnHover = 30;
            this.bunifuUserControl2.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuUserControl2.Image = null;
            this.bunifuUserControl2.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuUserControl2.Location = new System.Drawing.Point(5, 96);
            this.bunifuUserControl2.Name = "bunifuUserControl2";
            this.bunifuUserControl2.ShowBorders = true;
            this.bunifuUserControl2.Size = new System.Drawing.Size(383, 50);
            this.bunifuUserControl2.Style = Bunifu.UI.WinForms.BunifuUserControl.UserControlStyles.Flat;
            this.bunifuUserControl2.TabIndex = 1;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Active = false;
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Valider";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(276, 107);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(104, 23);
            this.bunifuFlatButton1.TabIndex = 5;
            this.bunifuFlatButton1.Text = "Valider";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Mongolian Baiti", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuMaterialTextbox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuMaterialTextbox1.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Enabled = false;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Century Gothic", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox1.HintText = "";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.Black;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineThickness = 5;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(101, 13);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.MaxLength = 32767;
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(347, 65);
            this.bunifuMaterialTextbox1.TabIndex = 13;
            this.bunifuMaterialTextbox1.Text = "Creation d\'une Compte";
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Parameters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 517);
            this.Controls.Add(this.bunifuMaterialTextbox1);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.bunifuUserControl1);
            this.Controls.Add(this.tb_matr);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bunifuUserControl2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Parameters";
            this.Text = "Parameters";
            this.bunifuUserControl1.ResumeLayout(false);
            this.bunifuUserControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_matr;
        private System.Windows.Forms.GroupBox bunifuUserControl1;
        private Bunifu.UI.WinForms.BunifuUserControl bunifuUserControl2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.UI.WinForms.BunifuUserControl bunifuUserControl1_;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_email;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_conf;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_mdp;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_adresse;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}