﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Office.Interop.Excel;

namespace projet_stage
{
    public partial class accueil : Form
    {
        public accueil()
        {
            InitializeComponent();
        }
        

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("file:///C:/Users/hp/Desktop/ISTA/MIFTAH/HTML/EasyForUs/First1.html");
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            conge c = new conge();
            c.Show();
            this.Hide();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            employe emp = new employe();
            emp.Show();
            this.Close();
        }

        private void bunifuImageButton6_Click(object sender, EventArgs e)
        {
            Parameters p = new Parameters();
            p.Show();
            this.Close();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            gerez g = new gerez();
            g.Show();
            this.Close();

        }

        private void bunifuImageButton5_Click(object sender, EventArgs e)
        { 
            pictureBox1.Visible = false;
            linkLabel1.Visible = false;
            linkLabel2.Visible = false;
            panel1.Visible = true;
            
            gest_equip m = new gest_equip()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.panel1.Controls.Add(m);
            m.Show();
            label1.Visible = false;
            label2.Visible = true;
        }

        private void bunifuSeparator4_Load(object sender, EventArgs e)
        {

        }

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox2_OnValueChanged(object sender, EventArgs e)
        {

            employe emp = new employe();
            emp.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox3_OnValueChanged(object sender, EventArgs e)
        {
            conge c = new conge();
            c.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox4_OnValueChanged(object sender, EventArgs e)
        {
            gest_equip g = new gest_equip();
            g.Show();
            this.Close();
        }

        private void accueil_Load(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
            linkLabel1.Visible = true;
            linkLabel2.Visible = true;
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
