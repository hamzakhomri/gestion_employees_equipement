﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class Form1 : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mn;
        string mon;
        accueil ac = new accueil();
        page1 g = new page1();
        progress_bar pr = new progress_bar();

        public Form1()
        {
            InitializeComponent();
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Parameters param = new Parameters();
            param.Show();
        }

        void verif_matr_comte()
        {
            con.Open();
            mon = null;
            string req = "select * from employe where matricule = @matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_matr.Text);

            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                groupBox3.Visible = true;

            }
            con.Close();
            if (mon == null)
            {
                MessageBox.Show("Vous avez Pas le Droit de Céer Une Compte", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                groupBox3.Visible = false;
            }
        }
        void verf_matr_empl()
        {
            con.Open();
            mon = null;
            string req = " select Matricule from  compte   where Matricule = @matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_matr.Text);

            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                if (MessageBox.Show("Vous avez déja un Compte                                                               Vous voulez Récupérer VOtre Compte ?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    g.Show();
                    groupBox3.Visible = false;
                }
                else
                    groupBox3.Visible = false;
            }
            con.Close();
            return;
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Parameters pa = new Parameters();
            pa.Show();
                 
        }

        private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            page1 p = new page1();
            p.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            verif_matr_comte();
            verf_matr_empl();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_adresse.Text == "" && tb_mdp.Text == "")
            {
                return;
            }
            mn = null;
            string req = "select logiin,mdp from compte where logiin = @log and mdp=@mdp";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@log", tb_adresse.Text);
            cmd.Parameters.AddWithValue("@mdp", tb_mdp.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                pr.Show();
               this.Hide();
                mn = lec.GetValue(0).ToString();
                mn = lec.GetValue(1).ToString();

            }
            lec.Close();
            con.Close();

            if (mn == null)
            {
                MessageBox.Show("L'adresse ou le mot de passe est incorrect .");
            }
            tb_mdp.Text = "";
            tb_adresse.Text = "";
        }

        void inscrire()
        {
            con.Open();
            string s = tb_email.Text.ToUpper();
            if (s.Substring(s.Length - 10, 10) == "@GMAIL.COM" && s.Length <= 25)
            {
                if (tb_conf.Text == bunifuTextBox1.Text)
                {
                    string req_ = "insert into compte values (@matr, @email,@log,@mdp)";
                    SqlCommand cmd_ = new SqlCommand(req_, con);
                    cmd_.Parameters.AddWithValue("@matr", tb_matr.Text);
                    cmd_.Parameters.AddWithValue("@email", tb_email.Text);
                    cmd_.Parameters.AddWithValue("@log", bunifuTextBox2.Text);
                    cmd_.Parameters.AddWithValue("@mdp", bunifuTextBox1.Text);
                    cmd_.ExecuteNonQuery();
                    MessageBox.Show("Votre Compte à été Créer", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                   
                    MessageBox.Show("la confirmation de mote de passe est inccorect");
                }
               
            }
            else
            {
                MessageBox.Show("Votre gmail est incorrect ", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
            groupBox3.Visible = true;
            
        }

     
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            string req = " select * from compte where logiin = @log or mdp = @mdp";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@log", bunifuTextBox2.Text);
            cmd.Parameters.AddWithValue("@mdp", bunifuTextBox1.Text);
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mn = lec.GetValue(2).ToString();
                mn = lec.GetValue(3).ToString();
                MessageBox.Show("inseret pas");
                
            }  con.Close();
            if (mn == null)
            {
                inscrire();
            }
        
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }  
}
