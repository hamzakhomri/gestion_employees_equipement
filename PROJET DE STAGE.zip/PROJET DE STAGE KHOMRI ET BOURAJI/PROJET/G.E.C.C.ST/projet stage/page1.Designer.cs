﻿namespace projet_stage
{
    partial class page1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(page1));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.tb_matricule = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_tel = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tb_service = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tb_email = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tb_nom = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tb_prenom = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tb_cat = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_mdp = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_adresse = new System.Windows.Forms.Label();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_matricule
            // 
            this.tb_matricule.AcceptsReturn = false;
            this.tb_matricule.AcceptsTab = false;
            this.tb_matricule.AnimationSpeed = 200;
            this.tb_matricule.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_matricule.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_matricule.BackColor = System.Drawing.Color.Transparent;
            this.tb_matricule.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_matricule.BackgroundImage")));
            this.tb_matricule.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_matricule.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_matricule.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_matricule.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_matricule.BorderRadius = 1;
            this.tb_matricule.BorderThickness = 1;
            this.tb_matricule.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tb_matricule.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_matricule.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_matricule.DefaultText = "";
            this.tb_matricule.FillColor = System.Drawing.Color.White;
            this.tb_matricule.HideSelection = true;
            this.tb_matricule.IconLeft = null;
            this.tb_matricule.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_matricule.IconPadding = 10;
            this.tb_matricule.IconRight = null;
            this.tb_matricule.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_matricule.Lines = new string[0];
            this.tb_matricule.Location = new System.Drawing.Point(0, 6);
            this.tb_matricule.MaxLength = 32767;
            this.tb_matricule.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_matricule.Modified = false;
            this.tb_matricule.Multiline = false;
            this.tb_matricule.Name = "tb_matricule";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_matricule.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_matricule.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_matricule.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_matricule.OnIdleState = stateProperties4;
            this.tb_matricule.PasswordChar = '\0';
            this.tb_matricule.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_matricule.PlaceholderText = "ENTER VOTRE MATRICULE";
            this.tb_matricule.ReadOnly = false;
            this.tb_matricule.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_matricule.SelectedText = "";
            this.tb_matricule.SelectionLength = 0;
            this.tb_matricule.SelectionStart = 0;
            this.tb_matricule.ShortcutsEnabled = true;
            this.tb_matricule.Size = new System.Drawing.Size(200, 35);
            this.tb_matricule.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_matricule.TabIndex = 4;
            this.tb_matricule.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_matricule.TextMarginBottom = 0;
            this.tb_matricule.TextMarginLeft = 5;
            this.tb_matricule.TextMarginTop = 0;
            this.tb_matricule.TextPlaceholder = "ENTER VOTRE MATRICULE";
            this.tb_matricule.UseSystemPasswordChar = false;
            this.tb_matricule.WordWrap = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tb_matricule);
            this.groupBox1.Location = new System.Drawing.Point(12, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 56);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_tel);
            this.groupBox2.Location = new System.Drawing.Point(218, 73);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 56);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // tb_tel
            // 
            this.tb_tel.AcceptsReturn = false;
            this.tb_tel.AcceptsTab = false;
            this.tb_tel.AnimationSpeed = 200;
            this.tb_tel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_tel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_tel.BackColor = System.Drawing.Color.Transparent;
            this.tb_tel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_tel.BackgroundImage")));
            this.tb_tel.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_tel.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_tel.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_tel.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_tel.BorderRadius = 1;
            this.tb_tel.BorderThickness = 1;
            this.tb_tel.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_tel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_tel.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_tel.DefaultText = "";
            this.tb_tel.FillColor = System.Drawing.Color.White;
            this.tb_tel.HideSelection = true;
            this.tb_tel.IconLeft = null;
            this.tb_tel.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_tel.IconPadding = 10;
            this.tb_tel.IconRight = null;
            this.tb_tel.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_tel.Lines = new string[0];
            this.tb_tel.Location = new System.Drawing.Point(0, 6);
            this.tb_tel.MaxLength = 32767;
            this.tb_tel.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_tel.Modified = false;
            this.tb_tel.Multiline = false;
            this.tb_tel.Name = "tb_tel";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_tel.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_tel.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_tel.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_tel.OnIdleState = stateProperties8;
            this.tb_tel.PasswordChar = '\0';
            this.tb_tel.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_tel.PlaceholderText = "Entrer Votre N ° de Tel";
            this.tb_tel.ReadOnly = false;
            this.tb_tel.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_tel.SelectedText = "";
            this.tb_tel.SelectionLength = 0;
            this.tb_tel.SelectionStart = 0;
            this.tb_tel.ShortcutsEnabled = true;
            this.tb_tel.Size = new System.Drawing.Size(200, 35);
            this.tb_tel.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_tel.TabIndex = 4;
            this.tb_tel.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_tel.TextMarginBottom = 0;
            this.tb_tel.TextMarginLeft = 5;
            this.tb_tel.TextMarginTop = 0;
            this.tb_tel.TextPlaceholder = "Entrer Votre N ° de Tel";
            this.tb_tel.UseSystemPasswordChar = false;
            this.tb_tel.WordWrap = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tb_service);
            this.groupBox3.Location = new System.Drawing.Point(424, 73);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 56);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            // 
            // tb_service
            // 
            this.tb_service.AcceptsReturn = false;
            this.tb_service.AcceptsTab = false;
            this.tb_service.AnimationSpeed = 200;
            this.tb_service.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_service.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_service.BackColor = System.Drawing.Color.Transparent;
            this.tb_service.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_service.BackgroundImage")));
            this.tb_service.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_service.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_service.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_service.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_service.BorderRadius = 1;
            this.tb_service.BorderThickness = 1;
            this.tb_service.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_service.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_service.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_service.DefaultText = "";
            this.tb_service.FillColor = System.Drawing.Color.White;
            this.tb_service.HideSelection = true;
            this.tb_service.IconLeft = null;
            this.tb_service.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_service.IconPadding = 10;
            this.tb_service.IconRight = null;
            this.tb_service.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_service.Lines = new string[0];
            this.tb_service.Location = new System.Drawing.Point(0, 6);
            this.tb_service.MaxLength = 32767;
            this.tb_service.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_service.Modified = false;
            this.tb_service.Multiline = false;
            this.tb_service.Name = "tb_service";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_service.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_service.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_service.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_service.OnIdleState = stateProperties12;
            this.tb_service.PasswordChar = '\0';
            this.tb_service.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_service.PlaceholderText = "Entrer votre service";
            this.tb_service.ReadOnly = false;
            this.tb_service.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_service.SelectedText = "";
            this.tb_service.SelectionLength = 0;
            this.tb_service.SelectionStart = 0;
            this.tb_service.ShortcutsEnabled = true;
            this.tb_service.Size = new System.Drawing.Size(200, 35);
            this.tb_service.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_service.TabIndex = 4;
            this.tb_service.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_service.TextMarginBottom = 0;
            this.tb_service.TextMarginLeft = 5;
            this.tb_service.TextMarginTop = 0;
            this.tb_service.TextPlaceholder = "Entrer votre service";
            this.tb_service.UseSystemPasswordChar = false;
            this.tb_service.WordWrap = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tb_email);
            this.groupBox4.Location = new System.Drawing.Point(12, 73);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 56);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            // 
            // tb_email
            // 
            this.tb_email.AcceptsReturn = false;
            this.tb_email.AcceptsTab = false;
            this.tb_email.AnimationSpeed = 200;
            this.tb_email.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_email.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_email.BackColor = System.Drawing.Color.Transparent;
            this.tb_email.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_email.BackgroundImage")));
            this.tb_email.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_email.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_email.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_email.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_email.BorderRadius = 1;
            this.tb_email.BorderThickness = 1;
            this.tb_email.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_email.DefaultText = "";
            this.tb_email.FillColor = System.Drawing.Color.White;
            this.tb_email.HideSelection = true;
            this.tb_email.IconLeft = null;
            this.tb_email.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.IconPadding = 10;
            this.tb_email.IconRight = null;
            this.tb_email.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.Lines = new string[0];
            this.tb_email.Location = new System.Drawing.Point(0, 6);
            this.tb_email.MaxLength = 32767;
            this.tb_email.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_email.Modified = false;
            this.tb_email.Multiline = false;
            this.tb_email.Name = "tb_email";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_email.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_email.OnIdleState = stateProperties16;
            this.tb_email.PasswordChar = '\0';
            this.tb_email.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_email.PlaceholderText = "Enter votre e-mail";
            this.tb_email.ReadOnly = false;
            this.tb_email.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_email.SelectedText = "";
            this.tb_email.SelectionLength = 0;
            this.tb_email.SelectionStart = 0;
            this.tb_email.ShortcutsEnabled = true;
            this.tb_email.Size = new System.Drawing.Size(200, 35);
            this.tb_email.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_email.TabIndex = 4;
            this.tb_email.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_email.TextMarginBottom = 0;
            this.tb_email.TextMarginLeft = 5;
            this.tb_email.TextMarginTop = 0;
            this.tb_email.TextPlaceholder = "Enter votre e-mail";
            this.tb_email.UseSystemPasswordChar = false;
            this.tb_email.WordWrap = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tb_nom);
            this.groupBox5.Location = new System.Drawing.Point(218, 11);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 56);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            // 
            // tb_nom
            // 
            this.tb_nom.AcceptsReturn = false;
            this.tb_nom.AcceptsTab = false;
            this.tb_nom.AnimationSpeed = 200;
            this.tb_nom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_nom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_nom.BackColor = System.Drawing.Color.Transparent;
            this.tb_nom.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_nom.BackgroundImage")));
            this.tb_nom.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_nom.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_nom.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_nom.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_nom.BorderRadius = 1;
            this.tb_nom.BorderThickness = 1;
            this.tb_nom.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_nom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_nom.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_nom.DefaultText = "";
            this.tb_nom.FillColor = System.Drawing.Color.White;
            this.tb_nom.HideSelection = true;
            this.tb_nom.IconLeft = null;
            this.tb_nom.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_nom.IconPadding = 10;
            this.tb_nom.IconRight = null;
            this.tb_nom.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_nom.Lines = new string[0];
            this.tb_nom.Location = new System.Drawing.Point(0, 6);
            this.tb_nom.MaxLength = 32767;
            this.tb_nom.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_nom.Modified = false;
            this.tb_nom.Multiline = false;
            this.tb_nom.Name = "tb_nom";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_nom.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Empty;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_nom.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_nom.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_nom.OnIdleState = stateProperties20;
            this.tb_nom.PasswordChar = '\0';
            this.tb_nom.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_nom.PlaceholderText = "Enter Votre nom";
            this.tb_nom.ReadOnly = false;
            this.tb_nom.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_nom.SelectedText = "";
            this.tb_nom.SelectionLength = 0;
            this.tb_nom.SelectionStart = 0;
            this.tb_nom.ShortcutsEnabled = true;
            this.tb_nom.Size = new System.Drawing.Size(200, 35);
            this.tb_nom.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_nom.TabIndex = 4;
            this.tb_nom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_nom.TextMarginBottom = 0;
            this.tb_nom.TextMarginLeft = 5;
            this.tb_nom.TextMarginTop = 0;
            this.tb_nom.TextPlaceholder = "Enter Votre nom";
            this.tb_nom.UseSystemPasswordChar = false;
            this.tb_nom.WordWrap = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tb_prenom);
            this.groupBox6.Location = new System.Drawing.Point(424, 11);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 56);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            // 
            // tb_prenom
            // 
            this.tb_prenom.AcceptsReturn = false;
            this.tb_prenom.AcceptsTab = false;
            this.tb_prenom.AnimationSpeed = 200;
            this.tb_prenom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_prenom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_prenom.BackColor = System.Drawing.Color.Transparent;
            this.tb_prenom.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_prenom.BackgroundImage")));
            this.tb_prenom.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_prenom.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_prenom.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_prenom.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_prenom.BorderRadius = 1;
            this.tb_prenom.BorderThickness = 1;
            this.tb_prenom.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_prenom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_prenom.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_prenom.DefaultText = "";
            this.tb_prenom.FillColor = System.Drawing.Color.White;
            this.tb_prenom.HideSelection = true;
            this.tb_prenom.IconLeft = null;
            this.tb_prenom.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_prenom.IconPadding = 10;
            this.tb_prenom.IconRight = null;
            this.tb_prenom.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_prenom.Lines = new string[0];
            this.tb_prenom.Location = new System.Drawing.Point(0, 6);
            this.tb_prenom.MaxLength = 32767;
            this.tb_prenom.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_prenom.Modified = false;
            this.tb_prenom.Multiline = false;
            this.tb_prenom.Name = "tb_prenom";
            stateProperties21.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_prenom.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Empty;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_prenom.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_prenom.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_prenom.OnIdleState = stateProperties24;
            this.tb_prenom.PasswordChar = '\0';
            this.tb_prenom.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_prenom.PlaceholderText = "Enter votre prenom";
            this.tb_prenom.ReadOnly = false;
            this.tb_prenom.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_prenom.SelectedText = "";
            this.tb_prenom.SelectionLength = 0;
            this.tb_prenom.SelectionStart = 0;
            this.tb_prenom.ShortcutsEnabled = true;
            this.tb_prenom.Size = new System.Drawing.Size(200, 35);
            this.tb_prenom.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_prenom.TabIndex = 4;
            this.tb_prenom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_prenom.TextMarginBottom = 0;
            this.tb_prenom.TextMarginLeft = 5;
            this.tb_prenom.TextMarginTop = 0;
            this.tb_prenom.TextPlaceholder = "Enter votre prenom";
            this.tb_prenom.UseSystemPasswordChar = false;
            this.tb_prenom.WordWrap = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tb_cat);
            this.groupBox7.Location = new System.Drawing.Point(12, 202);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(212, 56);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            // 
            // tb_cat
            // 
            this.tb_cat.AcceptsReturn = false;
            this.tb_cat.AcceptsTab = false;
            this.tb_cat.AnimationSpeed = 200;
            this.tb_cat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tb_cat.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tb_cat.BackColor = System.Drawing.Color.Transparent;
            this.tb_cat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_cat.BackgroundImage")));
            this.tb_cat.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tb_cat.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tb_cat.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tb_cat.BorderColorIdle = System.Drawing.Color.Silver;
            this.tb_cat.BorderRadius = 1;
            this.tb_cat.BorderThickness = 1;
            this.tb_cat.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tb_cat.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_cat.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tb_cat.DefaultText = "";
            this.tb_cat.FillColor = System.Drawing.Color.White;
            this.tb_cat.HideSelection = true;
            this.tb_cat.IconLeft = null;
            this.tb_cat.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_cat.IconPadding = 10;
            this.tb_cat.IconRight = null;
            this.tb_cat.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_cat.Lines = new string[0];
            this.tb_cat.Location = new System.Drawing.Point(12, 14);
            this.tb_cat.MaxLength = 32767;
            this.tb_cat.MinimumSize = new System.Drawing.Size(100, 35);
            this.tb_cat.Modified = false;
            this.tb_cat.Multiline = false;
            this.tb_cat.Name = "tb_cat";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_cat.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Empty;
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.Empty;
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_cat.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_cat.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tb_cat.OnIdleState = stateProperties28;
            this.tb_cat.PasswordChar = '\0';
            this.tb_cat.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tb_cat.PlaceholderText = "Entrer Votre Categorie";
            this.tb_cat.ReadOnly = false;
            this.tb_cat.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_cat.SelectedText = "";
            this.tb_cat.SelectionLength = 0;
            this.tb_cat.SelectionStart = 0;
            this.tb_cat.ShortcutsEnabled = true;
            this.tb_cat.Size = new System.Drawing.Size(200, 35);
            this.tb_cat.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tb_cat.TabIndex = 19;
            this.tb_cat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_cat.TextMarginBottom = 0;
            this.tb_cat.TextMarginLeft = 5;
            this.tb_cat.TextMarginTop = 0;
            this.tb_cat.TextPlaceholder = "Entrer Votre Categorie";
            this.tb_cat.UseSystemPasswordChar = false;
            this.tb_cat.WordWrap = true;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Active = false;
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Recuperer";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(24, 279);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(188, 48);
            this.bunifuFlatButton1.TabIndex = 10;
            this.bunifuFlatButton1.Text = "Recuperer";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuMaterialTextbox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuMaterialTextbox1.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Enabled = false;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Century Gothic", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox1.HintText = "";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.Black;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineThickness = 5;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(178, 2);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.MaxLength = 32767;
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(369, 65);
            this.bunifuMaterialTextbox1.TabIndex = 12;
            this.bunifuMaterialTextbox1.Text = "Recuperation du Compte";
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox1);
            this.groupBox8.Controls.Add(this.groupBox2);
            this.groupBox8.Controls.Add(this.groupBox3);
            this.groupBox8.Controls.Add(this.groupBox4);
            this.groupBox8.Controls.Add(this.groupBox6);
            this.groupBox8.Controls.Add(this.groupBox5);
            this.groupBox8.Location = new System.Drawing.Point(12, 74);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(636, 136);
            this.groupBox8.TabIndex = 13;
            this.groupBox8.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Votre Adresse c\'est :";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.label3);
            this.groupBox9.Controls.Add(this.label1);
            this.groupBox9.Controls.Add(this.lb_mdp);
            this.groupBox9.Controls.Add(this.label2);
            this.groupBox9.Controls.Add(this.lb_adresse);
            this.groupBox9.Location = new System.Drawing.Point(332, 279);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(355, 100);
            this.groupBox9.TabIndex = 17;
            this.groupBox9.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(193, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "_";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(193, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "_";
            // 
            // lb_mdp
            // 
            this.lb_mdp.AutoSize = true;
            this.lb_mdp.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mdp.Location = new System.Drawing.Point(192, 48);
            this.lb_mdp.Name = "lb_mdp";
            this.lb_mdp.Size = new System.Drawing.Size(13, 20);
            this.lb_mdp.TabIndex = 16;
            this.lb_mdp.Text = ".";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Votre Mot de passe c\'est :";
            // 
            // lb_adresse
            // 
            this.lb_adresse.AutoSize = true;
            this.lb_adresse.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_adresse.Location = new System.Drawing.Point(192, 16);
            this.lb_adresse.Name = "lb_adresse";
            this.lb_adresse.Size = new System.Drawing.Size(13, 20);
            this.lb_adresse.TabIndex = 15;
            this.lb_adresse.Text = ".";
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Active = false;
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Annuler";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(24, 336);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(188, 48);
            this.bunifuFlatButton2.TabIndex = 18;
            this.bunifuFlatButton2.Text = "Annuler";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // page1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 396);
            this.Controls.Add(this.bunifuFlatButton2);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.bunifuMaterialTextbox1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "page1";
            this.Text = "Recuperation du compte";
            this.Load += new System.EventHandler(this.page1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_matricule;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_tel;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_service;
        private System.Windows.Forms.GroupBox groupBox4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_email;
        private System.Windows.Forms.GroupBox groupBox5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_nom;
        private System.Windows.Forms.GroupBox groupBox6;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_prenom;
        private System.Windows.Forms.GroupBox groupBox7;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox9;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tb_cat;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_mdp;
        private System.Windows.Forms.Label lb_adresse;
    }
}