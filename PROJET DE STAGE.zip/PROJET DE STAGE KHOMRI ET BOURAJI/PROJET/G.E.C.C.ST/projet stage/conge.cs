﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace projet_stage
{


    public partial class conge : Form
    {


        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);

        public conge()
        {
            InitializeComponent();
        }


        private void demandeDeStageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();

        }


        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            valid_conge v = new valid_conge();
            v.Show();
            this.Close();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            employe em = new employe();
            em.Show();
            this.Close();
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            conge c = new conge();
            c.Show();
            this.Close();
        }

        private void bunifuButton1_Click_1(object sender, EventArgs e)
        {
            demande_conge dc = new demande_conge();
            dc.Show();
            this.Close();
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {

            valid_conge vc = new valid_conge();
            vc.Show();
            this.Close();
        }

        private void bunifuButton3_Click(object sender, EventArgs e)
        {
            liste_congé lc = new liste_congé();
            lc.Show();
            this.Close();
        }

        private void bunifuButton4_Click(object sender, EventArgs e)
        {
            supprimer_conge sc = new supprimer_conge();
            sc.Show();
            this.Close();
        }

        private void bunifuImageButton5_Click(object sender, EventArgs e)
        {
            gest_equip g = new gest_equip();
            g.Show();
            this.Close();
        }

        private void accueilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
           

        }

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void bunifuMaterialTextbox2_OnValueChanged(object sender, EventArgs e)
        {
            employe em = new employe();
            em.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox3_OnValueChanged(object sender, EventArgs e)
        {
            conge co = new conge();
            co.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox4_OnValueChanged(object sender, EventArgs e)
        {
            gest_equip g = new gest_equip();
            g.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void conge_Load(object sender, EventArgs e)
        {
            //string req = "select c.num_demande,c.matricule,e.nom,e.prenom,e.categorie,c.nature_conge,e.serviice,c.date_demande,c.date_debut,c.date_fin,c.nmb_jour from congé c inner join employe e on c.matricule=e.matricule ";
            //SqlCommand cmd = new SqlCommand(req, con);

            //con.Open();
            //SqlDataReader lec = cmd.ExecuteReader();
            //while (lec.Read())
            //{
            //    dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6), lec.GetValue(7), lec.GetValue(8), lec.GetValue(9), lec.GetValue(10), lec.GetValue(11), lec.GetValue(12));
            //}
            //lec.Close();
            //con.Close();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Controls.Clear();
            liste_congé m = new liste_congé()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Controls.Clear();
            supprimer_conge m = new supprimer_conge()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Controls.Clear();
            demande_conge m = new demande_conge()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Controls.Clear();
            valid_conge m = new valid_conge()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
        }
    }
}
