﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class gest_equip : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=stage;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
        string mon;
        string mn;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();

        public gest_equip()
        {
            InitializeComponent();
        }
        void tb()
        {
            con.Open();
            mn = null;
            string req = "select * from stock where n_dequipemet=@nd ";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@nd", tb_rechercher.Text);
            SqlDataReader lec = cmd.ExecuteReader();
            if (lec.Read())
            {
                tb_num_dequipement.Text = lec.GetValue(0).ToString();
                tb_ot.Text = lec.GetValue(1).ToString();
                tb_designation.Text = lec.GetValue(2).ToString();
                tb_emplacement.Text = lec.GetValue(3).ToString();
                tb_unite.Text = lec.GetValue(4).ToString();
                tb_qte.Text = lec.GetValue(5).ToString();
                tb_date.Text = lec.GetValue(6).ToString();
                con.Close();
            }
            else
            {
                MessageBox.Show("Test");
            }
        }
        void afficher()
        {
            dataGridView1.Rows.Clear();
            string req = "Select * from stock  order by n_dequipemet asc ";
            con.Open();
            SqlCommand cmd = new SqlCommand(req, con);
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6));
            }
            label13.Text = dataGridView1.RowCount.ToString();
            con.Close();

            tb_date.Text = DateTime.Now.ToString();
        }
        void sum()
        {
            dataGridView1.Rows.Clear();
            string req = "select sum(qte_rest) from stock  ";
            con.Open();
            SqlCommand cmd = new SqlCommand(req, con);
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                tatl.Text = lec.GetValue(0).ToString();
            }
            label13.Text = dataGridView1.RowCount.ToString();
            con.Close();
            tb_date.Text = DateTime.Now.ToString();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            sum();
            dt.Columns.Add("N D'équipement");
            dt.Columns.Add("N OT");
            dt.Columns.Add("DEsignation");
            dt.Columns.Add("Emplacement");
            dt.Columns.Add("Unité");
            dt.Columns.Add("Qte Restant");
            dt.Columns.Add("Date de sortie");
            afficher();
        }

        void search_n()
        {
            mon = null;
            if (tb_rechercher.Text == "")
            {
                MessageBox.Show("Il faut Remplir la zone de recherche ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string req = "select * from stock where n_dequipemet=@n";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@n", tb_rechercher.Text);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6));
            }

            lec.Close();
            con.Close();
            tb();
            if (mon == null)
            {
                MessageBox.Show("Cette equipement n'existe pas .");
            }
        }

        void search_date()
        {
            mon = null;
            if (tb_rechercher.Text == "")
            {
                MessageBox.Show("Il faut Remplir la zone de recherche ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                string req = "select * from stock where date_sorie=@n";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@n", DateTime.Parse(tb_rechercher.Text));
                con.Open();
                SqlDataReader lec = cmd.ExecuteReader();
                while (lec.Read())
                {
                    mon = lec.GetValue(0).ToString();

                    dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6));
                }
                tb();
                lec.Close();
                con.Close();
            }
            if (mon == null)
            {
                MessageBox.Show("Cette equipement n'existe pas .");
            }
        }
       
        void max()
        {
            string req = "select * from stock order by qte_rest asc";
            SqlCommand cmd = new SqlCommand(req, con);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6));
            }
            lec.Close();
            con.Close();
        }

        void min()
        {
               
            string req = "select * from stock order by qte_rest desc";
            SqlCommand cmd = new SqlCommand(req, con);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                dataGridView1.Rows.Add(lec.GetValue(0), lec.GetValue(1), lec.GetValue(2), lec.GetValue(3), lec.GetValue(4), lec.GetValue(5), lec.GetValue(6));
            }
            lec.Close();
            con.Close();
        }

        private void ajouter_Click(object sender, EventArgs e)
        {

            if (tb_designation.Text == "" || tb_emplacement.Text == "" || tb_num_dequipement.Text == "" || tb_ot.Text == "" || tb_qte.Text == "" || tb_unite.Text == "")
            {
                MessageBox.Show("Il faut Remplir tout les zones", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string req = " insert into stock values( @n_dequip , @n_ot , @designation , @emplacement , @unite , @qte , @date)";

                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@n_dequip", tb_num_dequipement.Text);
                cmd.Parameters.AddWithValue("@n_ot", tb_ot.Text);
                cmd.Parameters.AddWithValue("@designation", tb_designation.Text);
                cmd.Parameters.AddWithValue("@emplacement", tb_emplacement.Text);
                cmd.Parameters.AddWithValue("@unite", tb_unite.Text);
                cmd.Parameters.AddWithValue("@qte", int.Parse(tb_qte.Text));
                cmd.Parameters.AddWithValue("@date", DateTime.Parse(tb_date.Text)/*.ToString("dd/mm/yyyy")*/);


                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                afficher();
                
                tb_num_dequipement.Clear();
                tb_ot.Clear();
                tb_designation.Clear();
                tb_emplacement.Clear();
                tb_unite.Clear();
                tb_qte.Clear();
                tb_date.Text = DateTime.Now.ToString();
                MessageBox.Show("L'ajoute a été Réussi .", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            tb_num_dequipement.Focus();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (tb_rechercher.Text == "")
            {
                MessageBox.Show("Il faut Rechercher par N° D'équipment si existe ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information
            );
            }
            else if (MessageBox.Show("vous voulez Modifier cette equipement ?", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string req = "update stock set  n_ot= @not, designation=@designation , emplacement=@emplacement , unite=@unite , qte_rest=@qte_rest ,date_sorie=@date  where n_dequipemet=@n_equip";
                SqlCommand cmd = new SqlCommand(req, con);

                cmd.Parameters.AddWithValue("@not", tb_unite.Text);
                cmd.Parameters.AddWithValue("@designation", tb_ot.Text);
                cmd.Parameters.AddWithValue("@emplacement", tb_designation.Text);
                cmd.Parameters.AddWithValue("@unite", tb_emplacement.Text);
                cmd.Parameters.AddWithValue("@qte_rest", int.Parse(tb_qte.Text));
                cmd.Parameters.AddWithValue("@date", DateTime.Parse(tb_date.Text));
                cmd.Parameters.AddWithValue("@n_equip", tb_rechercher.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                afficher();
                
                tb_num_dequipement.Clear();
                tb_ot.Clear();
                tb_designation.Clear();
                tb_emplacement.Clear();
                tb_unite.Clear();
                tb_qte.Clear();
            }
        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            if (tb_rechercher.Text == "")
            {
                MessageBox.Show("Il faut Rechercher par N° D'équipment si existe ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (MessageBox.Show("vous voulez supprimer cette equipement ?", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string req = "delete from stock where n_dequipemet =@n_eq ";
                SqlCommand cmd = new SqlCommand(req, con);
                cmd.Parameters.AddWithValue("@n_eq", tb_rechercher.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(" La suppression  a ete bien effectue ", "Information", MessageBoxButtons.OK);
                afficher();
                tb_num_dequipement.Focus();
            }
        }

        private void modifier_Click(object sender, EventArgs e)
        {
            sum();
            afficher();
            tb_date.Text = DateTime.Now.ToString();
            tb_num_dequipement.Clear();
            tb_ot.Clear();
            tb_designation.Clear();
            tb_emplacement.Clear();
            tb_unite.Clear();
            tb_qte.Clear();
            tb_rechercher.Clear();
            tb_date.Text = DateTime.Now.ToString();
            rb_max.Checked = false;
            rb_min.Checked = false;
            date_sortie.Checked = false;
            n_equipement.Checked = false;
            tb_num_dequipement.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelApp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        xcelApp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    } 
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
            }
        }

        private void rechercher_Click(object sender, EventArgs e)
        {
            if (date_sortie.Checked == true)
            { dataGridView1.Rows.Clear(); search_date(); }

            else if (n_equipement.Checked == true)
            {
                dataGridView1.Rows.Clear(); search_n();
            }
            else { MessageBox.Show(" il faut coche une boutton pour effectue cette recherche ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information); }

            tb_num_dequipement.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rb_max.Checked) { dataGridView1.Rows.Clear(); max(); }
            if (rb_min.Checked) { dataGridView1.Rows.Clear(); min(); }
            rb_max.Checked = false;
            rb_min.Checked = false;
            tb_num_dequipement.Focus();
        }

        private void gest_equip_Load(object sender, EventArgs e)
        {
            sum();
            dt.Columns.Add("N D'équipement");
            dt.Columns.Add("N OT");
            dt.Columns.Add("DEsignation");
            dt.Columns.Add("Emplacement");
            dt.Columns.Add("Unité");
            dt.Columns.Add("Qte Restant");
            dt.Columns.Add("Date de sortie");
            afficher(); tb_num_dequipement.Focus();
        }

        private void retourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }
        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (rb_max.Checked) { max(); }
            if (rb_min.Checked) { min(); }
            rb_max.Checked = false;
            rb_min.Checked = false;
            tb_num_dequipement.Focus();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
