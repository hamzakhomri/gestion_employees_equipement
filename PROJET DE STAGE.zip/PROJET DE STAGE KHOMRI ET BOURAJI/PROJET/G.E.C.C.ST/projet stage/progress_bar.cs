﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet_stage
{
    public partial class progress_bar : Form
    {
        accueil ac = new accueil();

        public progress_bar()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            progressBar1.Value = Convert.ToInt32(progressBar1.Value + 10);
            if (progressBar1.Value == 100)
            {
                ac.Show();
                this.Close();
                this.timer1.Stop();
                progressBar1.Visible = false;
            }
        }

        private void progress_bar_Load(object sender, EventArgs e)
        {
            
            this.timer1.Start();
        }
    }
}
