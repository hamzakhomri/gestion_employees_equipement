﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet_stage
{
    public partial class employe : Form
    {
        public employe()
        {
            InitializeComponent();
        }




        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            employe em = new employe();
            em.Show();
            this.Close();
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            conge co = new conge();
            co.Show();
            this.Close();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {

            panel1.Visible = true ;
            panel1.Controls.Clear();
            afficher_tt pr = new afficher_tt()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
         
            this.panel1.Controls.Add(pr);
            pr.Show();
            bunifuTileButton1.Visible = false;
            bunifuTileButton2.Visible = false;
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            
            panel1.Visible = true;
            panel1.Controls.Clear();
            emp_panel m = new emp_panel()
            {

                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };

            this.panel1.Controls.Add(m);
            m.Show();
            bunifuTileButton1.Visible = false;
            bunifuTileButton2.Visible = false;
        }

        private void bunifuImageButton5_Click(object sender, EventArgs e)
        {

           
        }

        private void deconnecteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vous Voulez Vraiment Déconncter", "Questions", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {
            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox2_OnValueChanged(object sender, EventArgs e)
        {

            accueil ac = new accueil();
            ac.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox3_OnValueChanged(object sender, EventArgs e)
        {
            conge co = new conge();
            co.Show();
            this.Close();
        }

        private void bunifuMaterialTextbox4_OnValueChanged(object sender, EventArgs e)
        {
            gest_equip g = new gest_equip();
            g.Show();
            this.Close();
        }

        private void employe_Load(object sender, EventArgs e)
        {
            panel1.Visible= false;
        }
    }
}
