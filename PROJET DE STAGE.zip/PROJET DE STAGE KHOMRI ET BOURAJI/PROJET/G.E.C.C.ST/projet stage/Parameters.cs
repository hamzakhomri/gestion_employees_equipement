﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projet_stage
{
    public partial class Parameters : Form
    {
        static string cnx = "Data Source=DESKTOP-O8M7E3F;Initial Catalog=gestion_employe;Integrated Security=True";
        SqlConnection con = new SqlConnection(cnx);
         string mon;
        page1 g = new page1();

        public Parameters()
        {
            InitializeComponent();
        }

        void inscrire()
        {
            con.Open();
            string s = tb_email.Text.ToUpper();
            if (s.Substring(s.Length - 10, 10) == "@GMAIL.COM" && s.Length <= 25)
            {
                if (tb_conf.Text == tb_mdp.Text)
                {
                    string req_ = "insert into compte values (@matr, @email,@log,@mdp)";
                    SqlCommand cmd_ = new SqlCommand(req_, con);
                    cmd_.Parameters.AddWithValue("@matr", tb_matr.Text);
                    cmd_.Parameters.AddWithValue("@email", tb_email.Text);
                    cmd_.Parameters.AddWithValue("@log", tb_adresse.Text);
                    cmd_.Parameters.AddWithValue("@mdp", tb_mdp.Text);
                    cmd_.ExecuteNonQuery();
                    MessageBox.Show("Votre Compte à été Créer", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tb_matr.Focus();


                }
                else
                {
                    MessageBox.Show("la confirmation de mote de passe est inccorect");

                }
            }
            else
            {
                MessageBox.Show("Votre gmail est incorrect ", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            con.Close();
            bunifuUserControl1_.Visible = true;
            tb_matr.Clear();
        }
        


        void verif_matr_comte()
        {
            con.Open();
            mon = null;
            string req = "select * from employe where matricule = @matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_matr.Text);
           
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
               mon = lec.GetValue(0).ToString();
               bunifuUserControl1.Visible = true;

            }
            con.Close();
            if (mon == null)
            {
                MessageBox.Show("Vous avez Pas le Droit de Céer Une Compte","",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        void verf_matr_empl()
        {
            con.Open();
            mon = null;
            string req = " select Matricule from  compte   where Matricule = @matr";
            SqlCommand cmd = new SqlCommand(req, con);
            cmd.Parameters.AddWithValue("@matr", tb_matr.Text);

            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                if (MessageBox.Show("Vous avez déja un Compte                                                               Vous voulez Récupérer VOtre Compte ?","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    g.Show();
                    bunifuUserControl1.Visible = false;
                }
                else
                bunifuUserControl1.Visible = false;
            }
            con.Close();
            return;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            verif_matr_comte();
            verf_matr_empl();
            tb_email.Focus();
        }
        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string req = "select logiin,mdp from compte";
            SqlCommand cmd = new SqlCommand(req, con);
            con.Open();
            SqlDataReader lec = cmd.ExecuteReader();
            while (lec.Read())
            {
                mon = lec.GetValue(0).ToString();
                mon = lec.GetValue(1).ToString();
                MessageBox.Show("Changer L'adresse ou le mot de Passe","",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            con.Close();
            lec.Close();
            if (mon== null)
            {
                inscrire();
            }


        }

    }
    }


